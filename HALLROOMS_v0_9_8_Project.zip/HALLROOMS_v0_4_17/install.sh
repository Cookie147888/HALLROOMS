#!/usr/bin/env bash
set -euo pipefail
APP_NAME="HALLROOMS"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/$APP_NAME"
mkdir -p "$DEST"
cp -a "$ROOT/." "$DEST/"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
cat > "$HOME/.local/bin/HALLROOMS" <<EOF
#!/usr/bin/env bash
cd "$DEST"
exec godot --path "$DEST" "\$@"
EOF
chmod +x "$HOME/.local/bin/HALLROOMS"
cat > "$HOME/.local/share/applications/hallrooms.desktop" <<EOF
[Desktop Entry]
Name=HALLROOMS
Comment=Horror exploration game
Exec=$HOME/.local/bin/HALLROOMS
Terminal=false
Type=Application
Categories=Game;
EOF
if ! command -v godot >/dev/null 2>&1 && ! command -v godot4 >/dev/null 2>&1; then
  echo "Godot wurde nicht gefunden. Installiere es mit: sudo pacman -S godot"
fi
echo "HALLROOMS wurde nach $DEST installiert. Start: HALLROOMS"
