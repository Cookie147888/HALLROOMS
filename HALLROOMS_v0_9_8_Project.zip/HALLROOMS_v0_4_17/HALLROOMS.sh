#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if command -v godot >/dev/null 2>&1; then ENGINE=godot
elif command -v godot4 >/dev/null 2>&1; then ENGINE=godot4
else echo "Godot fehlt. Installiere mit: sudo pacman -S godot"; exit 1; fi
exec "$ENGINE" --path "$ROOT" "$@"
