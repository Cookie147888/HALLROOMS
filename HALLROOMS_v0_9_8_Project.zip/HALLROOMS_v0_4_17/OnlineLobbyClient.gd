extends Node
class_name OnlineLobbyClient

signal lobby_ready(peer: MultiplayerPeer, host: bool)
signal status_changed(message: String)
signal failed(message: String)

const SIGNALING_URL := "wss://hallrooms.onrender.com/ws"
const MAX_PEERS := 8
const SERVER_PEER_ID := 1

var socket := WebSocketPeer.new()
var multiplayer_peer: WebRTCMultiplayerPeer
var connections: Dictionary = {}
var pending_candidates: Dictionary = {}
var remote_description_set: Dictionary = {}
var pending_signals: Dictionary = {}
var mode := ""
var room_uuid := ""
var player_uuid := ""
var _sent_registration := false
var _ready_emitted := false
var _heartbeat_elapsed := 0.0

func start_host(host_uuid: String, local_uuid: String) -> Error:
	close()
	mode = "host"
	room_uuid = host_uuid
	player_uuid = local_uuid
	multiplayer_peer = WebRTCMultiplayerPeer.new()
	var peer_error := multiplayer_peer.create_server()
	if peer_error != OK:
		close()
		return peer_error
	return _open_signaling_socket()

func join_room(host_uuid: String, local_uuid: String) -> Error:
	close()
	mode = "join"
	room_uuid = host_uuid
	player_uuid = local_uuid
	return _open_signaling_socket()

func _open_signaling_socket() -> Error:
	if SIGNALING_URL.contains("YOUR-RENDER-SERVICE"):
		close()
		return ERR_UNCONFIGURED
	var err := socket.connect_to_url(SIGNALING_URL)
	if err != OK:
		close()
	return err

func _process(_delta: float) -> void:
	if mode.is_empty():
		return
	socket.poll()
	var state := socket.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN and _sent_registration:
		_heartbeat_elapsed += _delta
		if _heartbeat_elapsed >= 25.0:
			_heartbeat_elapsed = 0.0
			_send_signal_message({"type": "ping"})
	if state == WebSocketPeer.STATE_OPEN and not _sent_registration:
		_sent_registration = true
		_send_signal_message({
			"type": mode,
			"room": room_uuid,
			"player_uuid": player_uuid
		})
	elif state == WebSocketPeer.STATE_CLOSED:
		if not _ready_emitted:
			failed.emit("Verbindung zum Online-Vermittlungsserver fehlgeschlagen.")
		close()
		return
	while socket.get_ready_state() == WebSocketPeer.STATE_OPEN and socket.get_available_packet_count() > 0:
		var packet := socket.get_packet()
		var parsed: Variant = JSON.parse_string(packet.get_string_from_utf8())
		if parsed is Dictionary:
			_handle_server_message(parsed)
	for connection: WebRTCPeerConnection in connections.values():
		connection.poll()

func _handle_server_message(message: Dictionary) -> void:
	var message_type := str(message.get("type", ""))
	if message_type == "pong":
		return
	if message_type == "error":
		failed.emit(str(message.get("message", "Online-Verbindung fehlgeschlagen.")))
		return
	if mode == "host" and message_type == "host_ready":
		if not _ready_emitted:
			_ready_emitted = true
			lobby_ready.emit(multiplayer_peer, true)
			status_changed.emit("Online-Lobby bereit")
		return
	if mode == "host" and message_type == "peer_joined":
		_create_host_connection(int(message.get("peer_id", 0)), message.get("ice_servers", []))
		return
	if mode == "join" and message_type == "joined":
		var new_peer := WebRTCMultiplayerPeer.new()
		var local_peer_id := int(message.get("peer_id", 0))
		var create_error := new_peer.create_client(local_peer_id)
		if create_error != OK:
			failed.emit("WebRTC-Client konnte nicht gestartet werden: " + str(create_error))
			return
		multiplayer_peer = new_peer
		var connection := _new_connection(SERVER_PEER_ID, message.get("ice_servers", []))
		var add_error := multiplayer_peer.add_peer(connection, SERVER_PEER_ID)
		if add_error != OK:
			failed.emit("WebRTC-Verbindung konnte nicht hinzugefügt werden: " + str(add_error))
			return
		connections[SERVER_PEER_ID] = connection
		remote_description_set[SERVER_PEER_ID] = false
		_flush_signals(SERVER_PEER_ID)
		_ready_emitted = true
		lobby_ready.emit(multiplayer_peer, false)
		status_changed.emit("Mit UUID-Lobby verbunden; baue Verbindung auf …")
		return
	if message_type == "signal":
		_handle_peer_signal(message)
	elif message_type == "peer_left":
		var departed_id := int(message.get("peer_id", 0))
		if connections.has(departed_id):
			if multiplayer_peer and multiplayer_peer.has_peer(departed_id):
				multiplayer_peer.remove_peer(departed_id)
			else:
				connections[departed_id].close()
			connections.erase(departed_id)
			pending_candidates.erase(departed_id)
			remote_description_set.erase(departed_id)

func _create_host_connection(peer_id: int, ice_servers: Variant) -> void:
	if peer_id < 2 or peer_id > 2147483647 or connections.has(peer_id):
		return
	var connection := _new_connection(peer_id, ice_servers)
	var add_error := multiplayer_peer.add_peer(connection, peer_id)
	if add_error != OK:
		failed.emit("WebRTC-Verbindung konnte nicht hinzugefügt werden: " + str(add_error))
		return
	connections[peer_id] = connection
	remote_description_set[peer_id] = false
	_flush_signals(peer_id)
	var offer_error := connection.create_offer()
	if offer_error != OK:
		failed.emit("Verbindungsangebot konnte nicht erstellt werden: " + str(offer_error))

func _new_connection(peer_id: int, ice_servers: Variant) -> WebRTCPeerConnection:
	var connection := WebRTCPeerConnection.new()
	var configuration := {"iceServers": ice_servers if ice_servers is Array else []}
	var init_error := connection.initialize(configuration)
	if init_error != OK:
		failed.emit("WebRTC konnte nicht initialisiert werden: " + str(init_error))
	connection.session_description_created.connect(_on_session_description.bind(peer_id))
	connection.ice_candidate_created.connect(_on_ice_candidate.bind(peer_id))
	return connection

func _on_session_description(description_type: String, sdp: String, peer_id: int) -> void:
	if not connections.has(peer_id):
		return
	var connection: WebRTCPeerConnection = connections[peer_id]
	var err := connection.set_local_description(description_type, sdp)
	if err != OK:
		failed.emit("WebRTC-Beschreibung konnte nicht gespeichert werden: " + str(err))
		return
	_send_signal_message({
		"type": "signal",
		"to": peer_id,
		"data": {"kind": "description", "description_type": description_type, "sdp": sdp}
	})

func _on_ice_candidate(media: String, index: int, candidate: String, peer_id: int) -> void:
	_send_signal_message({
		"type": "signal",
		"to": peer_id,
		"data": {"kind": "candidate", "media": media, "index": index, "candidate": candidate}
	})

func _handle_peer_signal(message: Dictionary) -> void:
	var peer_id := int(message.get("from", SERVER_PEER_ID if mode == "join" else 0))
	if mode == "join":
		peer_id = SERVER_PEER_ID
	if not connections.has(peer_id):
		var queued: Array = pending_signals.get(peer_id, [])
		queued.append(message)
		pending_signals[peer_id] = queued
		return
	_apply_peer_signal(message, peer_id)

func _flush_signals(peer_id: int) -> void:
	if not pending_signals.has(peer_id):
		return
	var queued: Array = pending_signals[peer_id]
	pending_signals.erase(peer_id)
	for message: Dictionary in queued:
		_apply_peer_signal(message, peer_id)

func _apply_peer_signal(message: Dictionary, peer_id: int) -> void:
	var data: Variant = message.get("data", {})
	if not data is Dictionary:
		return
	var connection: WebRTCPeerConnection = connections[peer_id]
	if data.get("kind", "") == "description":
		var err := connection.set_remote_description(str(data.get("description_type", "")), str(data.get("sdp", "")))
		if err != OK:
			failed.emit("WebRTC-Gegenstellenbeschreibung konnte nicht übernommen werden: " + str(err))
			return
		remote_description_set[peer_id] = true
		_flush_candidates(peer_id)
	elif data.get("kind", "") == "candidate":
		var candidate := {
			"media": str(data.get("media", "")),
			"index": int(data.get("index", 0)),
			"candidate": str(data.get("candidate", ""))
		}
		if bool(remote_description_set.get(peer_id, false)):
			connection.add_ice_candidate(candidate.media, candidate.index, candidate.candidate)
		else:
			var queued: Array = pending_candidates.get(peer_id, [])
			queued.append(candidate)
			pending_candidates[peer_id] = queued

func _flush_candidates(peer_id: int) -> void:
	if not pending_candidates.has(peer_id) or not connections.has(peer_id):
		return
	var connection: WebRTCPeerConnection = connections[peer_id]
	for candidate: Dictionary in pending_candidates[peer_id]:
		connection.add_ice_candidate(str(candidate.media), int(candidate.index), str(candidate.candidate))
	pending_candidates.erase(peer_id)

func _send_signal_message(message: Dictionary) -> void:
	if socket.get_ready_state() == WebSocketPeer.STATE_OPEN:
		socket.send_text(JSON.stringify(message))

func close() -> void:
	if socket.get_ready_state() == WebSocketPeer.STATE_OPEN or socket.get_ready_state() == WebSocketPeer.STATE_CONNECTING:
		socket.close()
	for connection: WebRTCPeerConnection in connections.values():
		connection.close()
	connections.clear()
	pending_candidates.clear()
	remote_description_set.clear()
	pending_signals.clear()
	socket = WebSocketPeer.new()
	multiplayer_peer = null
	mode = ""
	room_uuid = ""
	player_uuid = ""
	_sent_registration = false
	_ready_emitted = false
	_heartbeat_elapsed = 0.0
