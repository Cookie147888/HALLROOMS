# HALLROOMS Render Signaling Server (STUN-only)

This Node.js service creates UUID lobbies and relays WebRTC signaling messages. It does not include or require a TURN relay. It provides a STUN server address so players can attempt a direct connection.

## Deploy on Render

1. Put this project in a GitHub repository and connect it to Render as a Blueprint. Render reads `render.yaml` from the project root and uses `server/` as the service directory.
2. Wait for the deploy to finish. Open `https://YOUR-SERVICE.onrender.com/healthz`; a healthy service returns `{"ok":true,"rooms":0}`.
3. The Godot project is configured with `wss://hallrooms.onrender.com/ws` in `OnlineLobbyClient.gd`; export and install the updated game.

If deploying this directory as its own repository, set the Render service to Node, build command `npm ci`, start command `npm start`, and health-check path `/healthz`.

## Limits

Render's free web services can sleep after inactivity and may restart. The game sends a small heartbeat every 25 seconds while a lobby is open, but any service restart clears all in-memory lobbies. STUN-only WebRTC can fail when either player's network blocks direct peer-to-peer connections. In that case this service has no relay fallback.
