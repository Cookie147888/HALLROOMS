"use strict";

const http = require("node:http");
const { WebSocketServer, WebSocket } = require("ws");

const port = Number(process.env.PORT || 8080);
const rooms = new Map();
const socketState = new WeakMap();

function compactUuid(value) {
  const compact = String(value || "").trim().toLowerCase().replaceAll("-", "");
  return /^[0-9a-f]{32}$/.test(compact) ? compact : "";
}

function iceServers() {
  return [{ urls: ["stun:stun.l.google.com:19302"] }];
}

function send(socket, message) {
  if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
}

function reject(socket, message) {
  send(socket, { type: "error", message });
  socket.close(1008, "request rejected");
}

function allocatePeerId(room) {
  let id = 0;
  do {
    id = crypto.randomInt(2, 2147483647);
  } while (room.clients.has(id));
  return id;
}

function removeSocket(socket) {
  const state = socketState.get(socket);
  if (!state) return;
  socketState.delete(socket);
  const room = rooms.get(state.room);
  if (!room) return;
  if (state.role === "host") {
    for (const client of room.clients.values()) {
      send(client.socket, { type: "error", message: "Der Host hat die Lobby geschlossen." });
      client.socket.close(1000, "host left");
      socketState.delete(client.socket);
    }
    rooms.delete(state.room);
    return;
  }
  room.clients.delete(state.peerId);
  send(room.host, { type: "peer_left", peer_id: state.peerId });
  if (room.clients.size === 0 && room.host.readyState !== WebSocket.OPEN) rooms.delete(state.room);
}

const server = http.createServer((request, response) => {
  if (request.url === "/healthz") {
    response.writeHead(200, { "content-type": "application/json" });
    response.end(JSON.stringify({ ok: true, rooms: rooms.size }));
    return;
  }
  response.writeHead(404);
  response.end("Not found");
});

const websocketServer = new WebSocketServer({ server, path: "/ws", maxPayload: 256 * 1024 });
websocketServer.on("connection", (socket) => {
  socket.on("message", (raw) => {
    let message;
    try {
      message = JSON.parse(raw.toString("utf8"));
    } catch {
      reject(socket, "Ungültige Nachricht.");
      return;
    }
    if (!message || typeof message !== "object" || Array.isArray(message)) {
      reject(socket, "Ungültige Nachricht.");
      return;
    }

    if (message.type === "ping") {
      send(socket, { type: "pong" });
      return;
    }

    const state = socketState.get(socket);
    if (!state) {
      const roomId = compactUuid(message.room);
      const playerId = compactUuid(message.player_uuid);
      if (!roomId || !playerId) {
        reject(socket, "Lobby-UUID oder Spieler-UUID ist ungültig.");
        return;
      }
      if (message.type === "host") {
        if (rooms.has(roomId)) {
          reject(socket, "Diese UUID wird bereits von einer aktiven Lobby verwendet.");
          return;
        }
        const room = { host: socket, hostPlayer: playerId, clients: new Map() };
        rooms.set(roomId, room);
        socketState.set(socket, { role: "host", room: roomId, player: playerId });
        send(socket, { type: "host_ready", room: roomId });
        return;
      }
      if (message.type === "join") {
        const room = rooms.get(roomId);
        if (!room || room.host.readyState !== WebSocket.OPEN) {
          reject(socket, "Keine aktive Lobby mit dieser UUID gefunden.");
          return;
        }
        if (room.clients.size >= 7) {
          reject(socket, "Die Lobby ist bereits voll (maximal 8 Spieler).");
          return;
        }
        if (playerId === room.hostPlayer || [...room.clients.values()].some((client) => client.player === playerId)) {
          reject(socket, "Diese Spieler-UUID ist bereits in der Lobby.");
          return;
        }
        const peerId = allocatePeerId(room);
        const peerState = { role: "client", room: roomId, player: playerId, peerId };
        room.clients.set(peerId, { socket, player: playerId });
        socketState.set(socket, peerState);
        const servers = iceServers();
        send(socket, { type: "joined", room: roomId, peer_id: peerId, ice_servers: servers });
        send(room.host, { type: "peer_joined", peer_id: peerId, player_uuid: playerId, ice_servers: servers });
        return;
      }
      reject(socket, "Zuerst muss host oder join gesendet werden.");
      return;
    }

    if (message.type !== "signal" || !Number.isInteger(message.to) || !message.data || typeof message.data !== "object" || Array.isArray(message.data)) {
      reject(socket, "Ungültige Signalisierungsnachricht.");
      return;
    }
    const room = rooms.get(state.room);
    if (!room) {
      reject(socket, "Die Lobby wurde geschlossen.");
      return;
    }
    let recipient;
    let senderId;
    if (state.role === "host") {
      const target = room.clients.get(message.to);
      if (!target) {
        reject(socket, "Zielspieler ist nicht mehr in der Lobby.");
        return;
      }
      recipient = target.socket;
      senderId = 1;
    } else {
      if (message.to !== 1) {
        reject(socket, "Spieler dürfen Signale nur an den Host senden.");
        return;
      }
      recipient = room.host;
      senderId = state.peerId;
    }
    send(recipient, { type: "signal", from: senderId, data: message.data });
  });
  socket.on("close", () => removeSocket(socket));
  socket.on("error", () => removeSocket(socket));
});

server.listen(port, "0.0.0.0", () => {
  console.log(`HALLROOMS signaling server listening on ${port}`);
});

setInterval(() => {
  for (const [roomId, room] of rooms) {
    if (room.host.readyState !== WebSocket.OPEN) {
      removeSocket(room.host);
      rooms.delete(roomId);
    }
  }
}, 30000).unref();
