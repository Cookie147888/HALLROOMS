extends CharacterBody3D

var kind := "Flymouth"
var target: Node3D
var damage := 25
var speed := 2.0
var attack_cooldown := 0.0
var attack_interval := 1.35
var main_game: Node
var path_refresh_timer := 0.0
var boss_waypoint := Vector3.ZERO

func _ready() -> void:
	match kind:
		"Backterius 2.0":
			damage = 100
			speed = 1.65
		"Flymouth":
			damage = 25
			speed = 2.15
		"Helius":
			damage = 35
			speed = 2.8
		"Dlhite":
			damage = 100
			speed = 0.0
		"Smasher":
			damage = 50
			speed = 2.0
			attack_interval = 2.2
	if kind == "Smasher":
		_build_smsher_visual()
	else:
		var sprite := Sprite3D.new()
		sprite.name = "MonsterSprite"
		if kind == "Dlhite":
			sprite.texture = load("res://assets/monsters/dlhite.png")
			sprite.pixel_size = 0.00145
			sprite.position.y = 0.0
			collision_layer = 2
			collision_mask = 0
		else:
			sprite.texture = load("res://assets/monsters/%s.svg" % _file_name())
			sprite.pixel_size = 0.005
			sprite.position.y = 1.35
		sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		sprite.shaded = false
		sprite.no_depth_test = false
		add_child(sprite)
	var collision := CollisionShape3D.new()
	if kind == "Dlhite":
		var sphere := SphereShape3D.new()
		sphere.radius = 0.72
		collision.shape = sphere
	elif kind == "Smasher":
		var capsule := CapsuleShape3D.new()
		capsule.radius = 0.62
		capsule.height = 2.55
		collision.shape = capsule
		collision.position.y = 1.2
	else:
		var capsule := CapsuleShape3D.new()
		capsule.radius = 0.38
		capsule.height = 1.8
		collision.shape = capsule
		collision.position.y = 0.9
	add_child(collision)

func _build_smsher_visual() -> void:
	var body_material := _smsher_material(Color(0.045, 0.035, 0.045), 0.28)
	var armor_material := _smsher_material(Color(0.12, 0.10, 0.12), 0.52)
	var red_material := _smsher_material(Color(0.62, 0.035, 0.045), 0.12)
	var joint_material := _smsher_material(Color(0.20, 0.17, 0.18), 0.4)
	_add_smsher_sphere("Mantle", Vector3(0, 1.45, 0), Vector3(0.72, 0.78, 0.62), body_material)
	_add_smsher_sphere("Skull", Vector3(0, 2.35, -0.02), Vector3(0.57, 0.60, 0.48), armor_material)
	_add_smsher_sphere("EyeSocket", Vector3(0, 2.36, -0.40), Vector3(0.43, 0.39, 0.24), body_material)
	var eye_white := _smsher_material(Color(0.92, 0.84, 0.72), 0.0)
	var glowing_iris := _smsher_material(Color(0.92, 0.025, 0.035), 0.0)
	glowing_iris.emission_enabled = true
	glowing_iris.emission = Color(0.9, 0.02, 0.025)
	glowing_iris.emission_energy_multiplier = 1.8
	_add_smsher_sphere("Eye", Vector3(0, 2.38, -0.57), Vector3(0.31, 0.28, 0.16), eye_white)
	_add_smsher_sphere("Iris", Vector3(0, 2.38, -0.70), Vector3(0.19, 0.20, 0.09), glowing_iris)
	_add_smsher_sphere("Pupil", Vector3(0, 2.38, -0.775), Vector3(0.07, 0.15, 0.035), _smsher_material(Color(0.018, 0.012, 0.015), 0.0))
	for side in [-1.0, 1.0]:
		var fang := MeshInstance3D.new()
		var fang_mesh := CylinderMesh.new()
		fang_mesh.top_radius = 0.015
		fang_mesh.bottom_radius = 0.095
		fang_mesh.height = 0.35
		fang.mesh = fang_mesh
		fang.material_override = red_material
		fang.position = Vector3(side * 0.22, 1.92, -0.40)
		fang.rotation_degrees.z = side * 24.0
		add_child(fang)
	for leg_index in range(8):
		var angle := TAU * float(leg_index) / 8.0
		var outward := Vector3(cos(angle), 0.0, sin(angle))
		var hip := Vector3(outward.x * 0.43, 1.48, outward.z * 0.40)
		var knee := Vector3(outward.x * 1.02, 0.88, outward.z * 0.94)
		var foot := Vector3(outward.x * 1.62, 0.10, outward.z * 1.48)
		_add_smsher_segment(hip, knee, 0.115, armor_material)
		_add_smsher_segment(knee, foot, 0.075, body_material)
		_add_smsher_sphere("Knee_%d" % leg_index, knee, Vector3.ONE * 0.16, joint_material)
		_add_smsher_segment(foot, foot + outward * 0.26 + Vector3(0, -0.05, 0), 0.045, red_material)
	var eye_glow := OmniLight3D.new()
	eye_glow.position = Vector3(0, 2.36, -0.82)
	eye_glow.light_color = Color(0.86, 0.045, 0.035)
	eye_glow.light_energy = 1.25
	eye_glow.omni_range = 3.2
	add_child(eye_glow)
	var nameplate := Label3D.new()
	nameplate.text = "SMASHER"
	nameplate.position = Vector3(0, 3.28, 0)
	nameplate.font_size = 42
	nameplate.modulate = Color(1.0, 0.28, 0.20)
	nameplate.outline_size = 7
	nameplate.outline_modulate = Color(0.035, 0.02, 0.025)
	nameplate.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(nameplate)

func _smsher_material(color: Color, metalness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.32
	material.metallic = metalness
	return material

func _add_smsher_sphere(node_name: String, sphere_position: Vector3, sphere_scale: Vector3, material: Material) -> void:
	var part := MeshInstance3D.new()
	part.name = node_name
	var sphere := SphereMesh.new()
	sphere.radius = 1.0
	sphere.height = 2.0
	part.mesh = sphere
	part.position = sphere_position
	part.scale = sphere_scale
	part.material_override = material
	add_child(part)

func _add_smsher_segment(start: Vector3, finish: Vector3, radius: float, material: Material) -> void:
	var direction := finish - start
	var segment := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = radius * 0.72
	cylinder.bottom_radius = radius
	cylinder.height = direction.length()
	segment.mesh = cylinder
	segment.position = (start + finish) * 0.5
	segment.quaternion = Quaternion(Vector3.UP, direction.normalized())
	segment.material_override = material
	add_child(segment)

func _file_name() -> String:
	match kind:
		"Backterius 2.0":
			return "backterius"
		"Helius":
			return "helius"
		_:
			return "flymouth"

func _physics_process(delta: float) -> void:
	if kind == "Dlhite":
		velocity = Vector3.ZERO
		return
	if not is_instance_valid(target):
		return
	attack_cooldown -= delta
	var to_player: Vector3 = target.global_position - global_position
	to_player.y = 0
	var distance := to_player.length()
	if kind == "Smasher" and distance > 1.65:
		path_refresh_timer -= delta
		if path_refresh_timer <= 0.0:
			path_refresh_timer = 0.35
			if is_instance_valid(main_game) and main_game.has_method("get_boss_chase_target"):
				boss_waypoint = main_game.get_boss_chase_target(global_position, target.global_position)
		var to_waypoint: Vector3 = boss_waypoint - global_position
		to_waypoint.y = 0.0
		if to_waypoint.length() < 0.45:
			to_waypoint = to_player
		velocity = to_waypoint.normalized() * speed
		move_and_slide()
		look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z), Vector3.UP)
		return
	if distance > 1.45:
		var direction := to_player.normalized()
		velocity = direction * speed
		move_and_slide()
		look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z), Vector3.UP)
	elif attack_cooldown <= 0.0:
		velocity = Vector3.ZERO
		attack_cooldown = attack_interval
		if is_instance_valid(main_game) and main_game.has_method("damage_player"):
			main_game.damage_player(damage, kind)
	else:
		velocity = Vector3.ZERO
