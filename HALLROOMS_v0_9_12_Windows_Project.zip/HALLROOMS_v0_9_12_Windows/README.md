# HALLROOMS v0.9.12 (Entwicklungsstand)

## Windows

Öffne `project.godot` in Godot 4.7.2 und nutze **Projekt → Exportieren → Windows Desktop**. Das Windows-Preset ist eingerichtet. Für die Kamera: ins Spielfenster klicken und die Maus bewegen; **Esc** pausiert.

Der mitgelieferte Windows-Build besteht aus `HALLROOMS_v0_9_12_Windows.exe` und `libwebrtc_native.windows.template_release.x86_64.dll`. Beide Dateien müssen im selben Ordner bleiben.

Die Spielversion wird als **v0.9.12** angezeigt. **Update prüfen** sucht Windows-Releases mit Tags im Format `Windows_v0.x` und vergleicht sie ab dem installierten Stand `Windows_v0.1`. Andere Tags wie `v0.9.12` werden bei der Windows-Updateprüfung ignoriert.


## Start unter Arch Linux

```bash
sudo pacman -S godot
./HALLROOMS.sh
```

Optional systemweit im Benutzerkonto installieren:

```bash
./install.sh
```

## Ordner

- `assets/monsters/` – Monsterillustrationen
- `Main.gd`, `Player.gd`, `Monster.gd` – Spielskripte

## Neue Funktionen in 0.4

- Menüeintrag **Aussehen** mit vier Spielerfarben; Auswahl wird lokal unter `user://appearance.cfg` gespeichert.
- Multiplayer-Dialog mit dauerhafter UUID pro Installation und Online-Lobbys für bis zu 8 Spieler.
- Arch-Linux-Startskript `HALLROOMS.sh` und Installationsskript `install.sh`.
- Monster-SVGs liegen in `assets/monsters/`.
- 35 Räume mit heller Beleuchtung; Raum 35 ist Smasher im Labyrinth.
- Grafikdetails in den Einstellungen: Niedrig, Mittel und Hoch; höhere Stufen schalten zusätzliche Wandlampen und Schatten ein.
- In jedem Raum steht ein durchsuchbarer Schrank. Mit 25 % Wahrscheinlichkeit gibt es 10 $, mit 25 % einen Verband; ansonsten ist der Schrank leer.
- Verbände heilen 40 Leben. Unter Android über **VERBAND**, am PC mit **Q**; die Steuerung ist in den Einstellungen anpassbar.
- Multiplayer nutzt WebRTC mit einem UUID-Vermittlungsdienst und STUN für direkte Peer-Verbindungen. Direkte Verbindungen über verschiedene WLANs und Mobilfunknetze können funktionieren, sind ohne TURN-Relay aber nicht in jedem Netz möglich.
- Schrankfunde und Inventar werden ebenfalls zwischen Host und Clients abgeglichen.
- Monster bewegen sich mit Kollisionen und bleiben an Wänden hängen.

## Multiplayer über das Internet

Die UUID ist der Lobby-Schlüssel. Render vermittelt die Lobby und tauscht WebRTC-Verbindungsdaten über WebSocket aus. STUN hilft den Geräten, eine direkte Verbindung zu versuchen. Es gibt in dieser Version keinen TURN-Relay: Wenn Router oder Mobilfunknetze direkte Verbindungen verhindern, können sich die Spieler zwar in der Lobby finden, aber nicht miteinander spielen. Der Host muss während der Runde online bleiben. Spielerpositionen, Türen und Raumfortschritt werden synchronisiert; Monsterverhalten und erlittene Treffer berechnet jedes Gerät weiterhin lokal.

Das Projekt enthält den Render-Server unter `server/` und die offizielle Godot-Erweiterung `addons/webrtc_native/` für Desktop und Android. Richte den Vermittlungsdienst zuerst bei Render ein:

1. Lade dieses Projekt in ein GitHub-Repository hoch und verbinde es in Render als **Blueprint**. Render findet `render.yaml` im Projektordner und baut den Dienst aus `server/` mit dem kostenlosen Web-Service-Tarif.
2. Warte auf den erfolgreichen Deploy. Für dieses Repository lautet die Render-Adresse `https://hallrooms.onrender.com`. Öffne `/healthz`; die Antwort sollte `{"ok":true,"rooms":0}` enthalten.
3. Die Adresse `wss://hallrooms.onrender.com/ws` ist bereits in `OnlineLobbyClient.gd` eingetragen.
4. Exportiere die Android-App neu und installiere sie auf allen Geräten. Spieler geben weiterhin nur die UUID der Lobby ein.

Der kostenlose Render-Dienst kann nach längerer Inaktivität schlafen und beim nächsten Zugriff etwa eine Minute zum Aufwachen brauchen. Das Spiel sendet alle 25 Sekunden ein kleines Lebenszeichen, solange eine Lobby offen ist. Render kann Dienste trotzdem neu starten; dabei gehen aktive Lobbys verloren. Die Serveradresse ist in der App hinterlegt. Lobbydaten werden nur im Arbeitsspeicher gespeichert.

## Android

Android-Touchsteuerung: links unten die Richtungstasten zum Bewegen, rechts unten **RUN** zum Rennen und **VERBAND** zum Heilen. Auf der rechten Bildschirmhälfte wischen, um die Kamera zu drehen. Das Spiel ist auf Querformat ausgelegt.

Die Touchknöpfe lassen sich unter **Einstellungen → Touchknöpfe anpassen** einzeln verschieben und skalieren. Die Vorschau zeigt das Layout; Änderungen werden direkt auf dem Gerät gespeichert.

Das Android-Exportpreset liegt in `export_presets.cfg` (Android, arm64-v8a). Für einen APK-Export:

1. Godot 4.7 öffnen und das Projekt importieren.
2. Unter **Editor → Editor-Einstellungen → Export → Android** die Pfade für JDK, Android SDK, Debug-Keystore und `adb` eintragen. Auf diesem Rechner liegt das SDK unter `~/Android/Sdk`; die lokale SDK-Installation enthält Build Tools 36.0.0 und NDK 30.0.16248370.
3. Unter **Projekt → Exportieren** das Android-Preset auswählen, die Android-Exportvorlagen für dieselbe Godot-Version installieren und eine APK exportieren.

Die vorherige Version 0.4.13 wurde mit Godot 4.7.2 als signierte Debug-APK exportiert. Zum Export auf einem anderen Rechner müssen passende Android-Exportvorlagen installiert und in Godot Java-SDK- und Android-SDK-Pfade gesetzt werden. Auf dem Erstellungsrechner: OpenJDK 17 unter `/usr/lib/jvm/java-17-openjdk`, Android SDK unter `~/Android/Sdk`.

## Exportstatus

Release v0.9.12 baut auf v0.9.11 auf. Android-Versionscode 27 und Versionsname 0.9.12. Die Android-Exportvorlage muss zur installierten Godot-Version passen. Dieses Projekt wurde nicht als APK exportiert oder auf einem Gerät getestet.

## Maschinen-Schreie in v0.9.12

Maschinen in Raum 35 benötigen jetzt einen lauten Schrei über das Mikrofon. Android fragt nach der Mikrofonberechtigung; Ton wird nur lokal auf Lautstärke geprüft, nicht gespeichert oder übertragen. In den Einstellungen kann die Mikrofonverwendung ausgeschaltet werden. Wenn die Berechtigung verweigert wird oder kein Mikrofon verfügbar ist, erscheint eine Texteingabe: mindestens 10 Zeichen eintippen und **Absenden** drücken. Für Android aktiviert das Projekt die Audioeingabe und die Berechtigung `RECORD_AUDIO`.

## Aktualisierung 0.4.6

- Android startet fest im Querformat (Godot-Projektwert `SCREEN_LANDSCAPE`) mit einer 1280×720-Basisauflösung.
- Räume haben eine Rückwand; an Übergängen bleibt ein Durchgang mit der geöffneten Tür.
- Türen schwenken beim Öffnen sichtbar auf. Monster aus dem gerade verlassenen Raum werden entfernt.
- Schränke erscheinen nur noch in jedem vierten Raum.
- Das Multiplayer-IP-Feld ist größer, öffnet auf Android die Bildschirmtastatur und erhält beim Öffnen den Fokus.

## Aktualisierung 0.4.7

- Weniger einzelne Wanddekorationen und Wandlampen verkürzen den Aufbau jedes Raums.
- Es bleiben nur die drei zuletzt betretenen Raumgeometrien aktiv; weiter zurückliegende Raumteile werden freigegeben.
- Böden überlappen an den Türdurchgängen; Wände und die bewegliche Tür haben passende Kollisionen.
- Der nächste Raum wird beim Öffnen bereits während der Türanimation aufgebaut. Als zusätzliche Sicherung wird der Spieler bei einem seltenen Sturz in die Mitte des aktuellen Raums zurückgesetzt.

## Aktualisierung 0.4.8

- Die letzten drei Raumteile werden als bewegliche Umgebung gehalten; ältere Teile und ihre Schränke werden entfernt.
- Sobald ein alter Raum entfernt wird, schließt sich sein ehemaliger Durchgang mit einer Rückwand.
- Türblatt-Kollision folgt der Animation als `AnimatableBody3D`; der nächste Raum samt Boden wird vor dem Ende der Öffnungsanimation aufgebaut.

## Aktualisierung 0.4.9

- Godot-Typinferenz in der Raumverwaltung ist explizit typisiert, sodass Projekte mit „Warnungen als Fehler behandeln“ exportiert werden können.

## Aktualisierung 0.4.10

- Die Türkollision wird zu Beginn der Öffnungsanimation deaktiviert, sodass der animierte Türflügel den Durchgang nicht blockiert.

## Aktualisierung 0.4.11

- Einzelspielerrunden erhalten beim Start einen neuen Zufalls-Seed; Raummaße, Details und Begegnungen variieren dadurch pro Durchlauf.
- Beim Türwechsel werden nur Monster des verlassenen Raums entfernt.
- Raum 14 ist ein sicherer Shop ohne Monster. Dort gibt es Verbände für 5 $ und für 20 $ pro Kauf eine Erhöhung des maximalen und aktuellen Lebens um 20; die Shopkäufe werden im Multiplayer mit dem Host abgeglichen.
- In Raum 25 erscheint Backterius 2.0 garantiert. Raum 34 ist ein sicherer Shop mit einmaligem Bonus von 20 $. In Raum 35 wartet Smasher, ein einäugiger Gegner mit langen Spinnenbeinen: Finde fünf Maschinen und interagiere mit ihnen, um in jede hineinzuschreien. Jeder Treffer zieht 50 von 250 Smasher-Leben ab; erst nach fünf Treffern öffnet sich der Ausgang.
- Monster werden in ihren aktuellen Raum gesetzt und können so nicht mehr hinter den Raumgrenzen spawnen.

## Aktualisierung 0.4.12

- Jeder Spieler erhält beim ersten Start eine feste UUID, die lokal gespeichert bleibt.
- Hosts zeigen ihre UUID zum Teilen an; Mitspieler geben diese UUID ein.
- Diese ältere Version verwendet noch UUID-Suche im lokalen WLAN/LAN.

## Aktualisierung 0.4.13

- Dlhite aus der Zeichnung hängt zufällig an einer Wand oder Decke. Direkter Blickkontakt über 2 Sekunden am Stück ist tödlich.
- Der Monster-Index steht im Hauptmenü. Einträge mit Kurzbeschreibung werden dauerhaft freigeschaltet, sobald ein Monster im Spiel sichtbar war.
- Im Shop in Raum 14 gibt es zusätzlich zum Verband eine Waffe für 10 $. Sie hat einen Schuss und besiegt Backterius 2.0 bei einem Treffer. Am PC mit **F**, auf Android über **FEUER**.

## Aktualisierung 0.4.14

- Multiplayer-Lobbys werden über eine UUID auf einem öffentlichen Vermittlungsserver gefunden. Die Spielverbindung läuft anschließend über WebRTC statt über LAN-Broadcast und ENet.
- Dieses Serverpaket wurde in Version 0.4.15 durch Render-Konfiguration mit STUN-only ersetzt.
- Die offizielle `webrtc-native`-GDExtension enthält Linux-x86_64- und Android-arm64-Bibliotheken. Der Android-Export ist vorbereitet, sobald `SIGNALING_URL` auf den bereitgestellten Server zeigt.

## Aktualisierung 0.4.15

- Server für Render vorbereitet; er vermittelt UUID-Lobbys und WebRTC-Signalisierung ohne TURN.
- WebRTC verwendet STUN und versucht eine direkte Verbindung zwischen den Spielern. Manche Router oder Mobilfunknetze lassen das nicht zu.
- Ein Lebenszeichen alle 25 Sekunden hält eine offene Lobby auf Render aktiv, während Spieler warten.
- Ein kostenloser Render-Neustart beendet aktive Lobbys; Spieler müssen sie dann neu erstellen.

## Aktualisierung 0.4.16

- Die Meldung „Backterius 2.0 ist in der Nähe“ erscheint nicht mehr. Beim Erscheinen des Endgegners flackert stattdessen kurz die Beleuchtung.
- Ein Zielhinweis zeigt den Weg zum Shop in Raum 14 und den Endausgang in Raum 25.
- HUD-Fortschritt zeigt damit klarer, was als Nächstes zu tun ist.


## Aktualisierung 0.4.17

- Das Spiel umfasst jetzt 35 Räume. Der bisherige Backterius-Auftritt bleibt garantiert in Raum 25.
- Raum 34 enthält einen sicheren Shop und zahlt beim ersten Öffnen des Shops einmalig 20 $ aus.
- Raum 35 ist ein pro Durchlauf zufällig generiertes 7×7-Labyrinth mit Smasher nach der beigefügten Zeichnung.
- Fünf Schreimaschinen sind in verschiedenen Gängen verteilt. Jede Maschinen-Interaktion zählt als Hineinschreien und zieht 50 von 250 Smasher-Leben ab. Smasher jagt durch die Gänge; sein Kontaktangriff verursacht 50 Schaden.
- Die Ausgangstür bleibt gesperrt, bis alle fünf Maschinen aktiviert und Smasher besiegt ist. Der Monster-Index enthält jetzt Smasher.
- Android-Preset auf Versionscode 18 / Version 0.4.17 gesetzt. Dieses Projekt wurde nicht als APK exportiert oder auf einem Gerät getestet.

## Aktualisierung 0.4.18

- Im Hauptmenü gibt es **Update prüfen**. Die App fragt den GitHub-Releases-Endpunkt für das Tag `v0.9.11` ab.
- Wenn der Release gefunden wird, kann die Downloadseite im Browser geöffnet werden. Die App lädt oder installiert Updates nicht selbst.
- Bei einem privaten Repository kann GitHub den Release ohne Anmeldung nicht ausliefern. Es ist absichtlich kein persönliches Zugriffstoken in der App gespeichert.
- Android-Preset auf Versionscode 19 / Version 0.4.18 gesetzt. Diese Version wurde nicht als APK exportiert oder auf einem Gerät getestet.

## Aktualisierung 0.4.19

- Die Update-Prüfung im Hauptmenü durchsucht veröffentlichte GitHub-Releases nach Tags im Format `v0.x.y`.
- Sie vergleicht die höchste gefundene v0-Version mit der installierten Version 0.4.19. Neuere v0-Versionen werden angeboten; v1-Releases und Vorabversionen werden ignoriert.
- Bei einem Treffer öffnet die Bestätigung die passende GitHub-Release-Seite. Downloads und Installationen bleiben manuell.
- Android-Preset auf Versionscode 20 / Version 0.4.19 gesetzt. Diese Version wurde nicht als APK exportiert oder auf einem Gerät getestet.

## Release v0.9.11 (Vorgänger)

- Die Update-Prüfung vergleicht die installierte Version `v0.9.11` mit GitHub-Releases und erkennt beliebige höhere Versionsnummern, etwa `v0.9.12` oder `v1.0`.
- Bei einer neueren Version zeigt das Spiel deren Tag an und kann die passende Release-Seite öffnen. Download und Installation bleiben manuell.
- Android-Preset auf Versionscode 26 gesetzt; die Spielversion bleibt `v0.9.11`. Im Shop erhöht jeder Kauf für 20 $ das maximale und aktuelle Leben für diesen Durchlauf um 20; der Labyrinth-Boss heißt jetzt Smasher und nutzt ein neues dreidimensionales Modell. Diese Version wurde nicht als APK exportiert oder auf einem Gerät getestet.

## Release v0.9.12

- Maschinen im Smasher-Labyrinth erfordern einen lokalen Lautstärke-Schrei über das Mikrofon oder eine Texteingabe mit mindestens 10 Zeichen.
- Mikrofon kann in den Einstellungen deaktiviert werden. Audio wird weder gespeichert noch übertragen.
- Android-Mikrofonberechtigung und Audioeingabe sind im Projekt und Exportpreset aktiviert.
- Android-Versionscode 27, Spielversion 0.9.12. Keine APK erstellt oder auf einem Gerät getestet.
- Der Windows-Build zeigt Spielversion v0.9.12 an und prüft Updates ab Release-Tag `Windows_v0.1`.
