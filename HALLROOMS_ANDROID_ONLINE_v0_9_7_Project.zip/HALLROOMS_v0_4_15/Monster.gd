extends CharacterBody3D

var kind := "Flymouth"
var target: Node3D
var damage := 25
var speed := 2.0
var attack_cooldown := 0.0
var attack_interval := 1.35
var main_game: Node

func _ready() -> void:
	match kind:
		"Backterius 2.0":
			damage = 100
			speed = 1.65
		"Flymouth":
			damage = 25
			speed = 2.15
		"Helius":
			damage = 35
			speed = 2.8
		"Dlhite":
			damage = 100
			speed = 0.0
	var sprite := Sprite3D.new()
	sprite.name = "MonsterSprite"
	if kind == "Dlhite":
		sprite.texture = load("res://assets/monsters/dlhite.png")
		sprite.pixel_size = 0.00145
		sprite.position.y = 0.0
		collision_layer = 2
		collision_mask = 0
	else:
		sprite.texture = load("res://assets/monsters/%s.svg" % _file_name())
		sprite.pixel_size = 0.005
		sprite.position.y = 1.35
	sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sprite.shaded = false
	sprite.no_depth_test = false
	add_child(sprite)
	var collision := CollisionShape3D.new()
	if kind == "Dlhite":
		var sphere := SphereShape3D.new()
		sphere.radius = 0.72
		collision.shape = sphere
	else:
		var capsule := CapsuleShape3D.new()
		capsule.radius = 0.38
		capsule.height = 1.8
		collision.shape = capsule
		collision.position.y = 0.9
	add_child(collision)

func _file_name() -> String:
	match kind:
		"Backterius 2.0":
			return "backterius"
		"Helius":
			return "helius"
		_:
			return "flymouth"

func _physics_process(delta: float) -> void:
	if kind == "Dlhite":
		velocity = Vector3.ZERO
		return
	if not is_instance_valid(target):
		return
	attack_cooldown -= delta
	var to_player: Vector3 = target.global_position - global_position
	to_player.y = 0
	var distance := to_player.length()
	if distance > 1.45:
		var direction := to_player.normalized()
		velocity = direction * speed
		move_and_slide()
		look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z), Vector3.UP)
	elif attack_cooldown <= 0.0:
		velocity = Vector3.ZERO
		attack_cooldown = attack_interval
		if is_instance_valid(main_game) and main_game.has_method("damage_player"):
			main_game.damage_player(damage, kind)
	else:
		velocity = Vector3.ZERO
