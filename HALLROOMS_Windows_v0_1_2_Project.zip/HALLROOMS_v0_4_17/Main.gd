extends Node3D

const PLAYER_SCRIPT = preload("res://Player.gd")
const MONSTER_SCRIPT = preload("res://Monster.gd")
const ONLINE_LOBBY_SCRIPT = preload("res://OnlineLobbyClient.gd")
const MULTIPLAYER_WORLD_SEED := 481025
const MONSTER_ORDER := ["Flymouth", "Helius", "Dlhite", "Backterius 2.0", "Boss1"]
const BOSS_MAZE_COLUMNS := 7
const BOSS_MAZE_ROWS := 7
const BOSS_MAZE_CELL_SIZE := 4.45
const MONSTER_DESCRIPTIONS := {
	"Flymouth": ["Ein flatternder Jäger, der sich schnell nähert und aus der Nähe angreift.", "A fast flier that closes in and attacks at close range."],
	"Helius": ["Erscheint bei einem Stromausfall und jagt dich im Dunkeln.", "Appears during a blackout and hunts you in the dark."],
	"Dlhite": ["Hängt an Wänden oder Decken. Sieh es nie länger als 2 Sekunden direkt an.", "Clings to walls or ceilings. Never look directly at it for more than 2 seconds."],
	"Backterius 2.0": ["Ein gefährlicher Jäger in Raum 25.", "A dangerous hunter in Room 25."],
	"Boss1": ["Der Labyrinth-Boss in Raum 35. Finde fünf Schreimaschinen; jede nimmt ihm 50 Leben.", "The maze boss in Room 35. Find five scream machines; each removes 50 health."]
}

var rng := RandomNumberGenerator.new()
var loot_rng := RandomNumberGenerator.new()
var player: CharacterBody3D
var camera: Camera3D
var ui_layer: CanvasLayer
var menu_root: Control
var game_hud: Control
var pause_overlay: ColorRect
var settings_overlay: ColorRect
var preview_image: TextureRect
var preview_timer := 0.0
var preview_index := 0
var preview_paths := ["res://assets/monsters/backterius.svg", "res://assets/monsters/flymouth.svg", "res://assets/monsters/helius.svg", "res://assets/monsters/dlhite.png"]
var game_state := "menu"
var current_language := "de"
var health := 100
var money := 0
var bandages := 0
var weapon_ammo := 0
var monster_seen: Dictionary = {"Flymouth": false, "Helius": false, "Dlhite": false, "Backterius 2.0": false, "Boss1": false}
var watched_dlhite_id := 0
var dlhite_watch_time := 0.0
var searched_cabinets: Dictionary = {}
var door_number := 0
var end_z := 0.0
var room_index := 0
const TOTAL_ROOMS := 35
var current_room_width := 10.0
var current_room_length := 14.0
var room_roots: Array[Node3D] = []
var door_nodes: Array[Node3D] = []
var cabinet_nodes: Array[Node3D] = []
var monster_nodes: Array[Node3D] = []
var scream_machines: Array[Node3D] = []
var boss_maze_openings: Array = []
var boss_maze_origin_x := 0.0
var boss_maze_origin_z := 0.0
var boss_health := 250
var boss_hits_taken := 0
var boss_defeated := false
var room34_bonus_awarded := false
var shop_node: Node3D
var light_nodes: Array[OmniLight3D] = []
var game_environment: Environment
var graphics_quality := 2
var ui_scale := 1.0
var hud_enabled := true
var waiting_for_key := ""
var sensitivity_multiplier := 1.0
var hud_health: ProgressBar
var health_text: Label
var objective_text: Label
var inventory_text: Label
var door_text: Label
var hint_text: Label
var alert_text: Label
var settings_container: VBoxContainer
var binding_buttons: Dictionary = {}
var appearance_dialog: AcceptDialog
var index_dialog: AcceptDialog
var shop_dialog: AcceptDialog
var multiplayer_dialog: ConfirmationDialog
var multiplayer_uuid_input := LineEdit.new()
var player_uuid_display := LineEdit.new()
var uuid_search_dialog: AcceptDialog
var player_uuid := ""
var appearance_color := Color(0.35, 0.65, 0.82)
var appearance_colors := [Color(0.35,0.65,0.82), Color(0.78,0.48,0.36), Color(0.55,0.72,0.48), Color(0.68,0.55,0.82)]
var appearance_names := ["Blau", "Kupfer", "Grün", "Violett"]
var network_peer: MultiplayerPeer
var online_lobby: OnlineLobbyClient
var network_status := "Nicht verbunden"
var remote_players: Dictionary = {}
var network_pose_timer := 0.0
var player_body_mesh: MeshInstance3D
var touch_look_index := -1
var touch_look_sensitivity := 0.004
var mobile_controls: bool = OS.get_name() == "Android" or OS.get_name() == "iOS" or OS.has_feature("mobile")

var default_bindings := {
	"move_forward": KEY_W, "move_back": KEY_S, "move_left": KEY_A,
	"move_right": KEY_D, "sprint": KEY_SHIFT, "interact": KEY_E,
	"use_bandage": KEY_Q, "fire_weapon": KEY_F
}
var binding_names := {
	"move_forward": ["Vorwärts", "Move forward"],
	"move_back": ["Rückwärts", "Move backward"],
	"move_left": ["Links", "Move left"],
	"move_right": ["Rechts", "Move right"],
	"sprint": ["Rennen", "Sprint"],
	"interact": ["Tür öffnen / Schrank durchsuchen", "Open door / search cabinet"],
	"use_bandage": ["Verband benutzen", "Use bandage"],
	"fire_weapon": ["Waffe abfeuern", "Fire weapon"]
}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	rng.randomize()
	loot_rng.randomize()
	_load_or_create_player_uuid()
	_load_monster_index()
	_load_appearance()
	_load_user_settings()
	_setup_input()
	online_lobby = ONLINE_LOBBY_SCRIPT.new()
	add_child(online_lobby)
	online_lobby.lobby_ready.connect(_on_online_lobby_ready)
	online_lobby.status_changed.connect(_on_online_lobby_status)
	online_lobby.failed.connect(_on_online_lobby_failed)
	_make_interface()
	_show_main_menu()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)

func _input(event: InputEvent) -> void:
	if waiting_for_key != "":
		if event is InputEventKey and event.pressed and not event.echo:
			if event.keycode == KEY_ESCAPE:
				waiting_for_key = ""
			else:
				_set_binding(waiting_for_key, event.physical_keycode)
				waiting_for_key = ""
			_refresh_binding_buttons()
			get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("ui_cancel"):
		if game_state == "playing":
			_pause_game()
		elif game_state == "paused":
			_resume_game()
		elif game_state == "settings":
			_close_settings()
		get_viewport().set_input_as_handled()
		return
	if game_state == "playing":
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			_apply_mouse_look(event)
		_handle_touch_look(event)

func _apply_mouse_look(event: InputEventMouseMotion) -> void:
	if not is_instance_valid(player):
		return
	player.rotate_y(-event.relative.x * player.mouse_sensitivity)
	player.pitch = clamp(player.pitch - event.relative.y * player.mouse_sensitivity, -1.35, 1.35)
	if is_instance_valid(camera):
		camera.rotation.x = player.pitch

func _process(delta: float) -> void:
	if game_state == "menu":
		preview_timer += delta
		if preview_timer >= 5.0:
			preview_timer = 0.0
			preview_index = (preview_index + 1) % preview_paths.size()
			preview_image.texture = load(preview_paths[preview_index])
			preview_image.modulate.a = 0.0
		if preview_image.modulate.a < 1.0:
			preview_image.modulate.a = minf(1.0, preview_image.modulate.a + delta * 1.4)
	elif game_state == "playing":
		_recover_player_if_fallen()
		_update_door_prompt()
		_update_monster_visibility(delta)
		_sync_network_pose(delta)
		if Input.is_action_just_pressed("use_bandage"):
			_use_bandage()
		if Input.is_action_just_pressed("fire_weapon"):
			_fire_weapon()

func _tr(de: String, en: String) -> String:
	return de if current_language == "de" else en

func _handle_touch_look(event: InputEvent) -> void:
	var viewport_size := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			var in_pause_corner: bool = event.position.x > viewport_size.x * 0.78 and event.position.y < viewport_size.y * 0.20
			var in_action_corner: bool = event.position.x > viewport_size.x * 0.62 and event.position.y > viewport_size.y * 0.78
			if event.position.x > viewport_size.x * 0.42 and not in_pause_corner and not in_action_corner:
				touch_look_index = event.index
		elif event.index == touch_look_index:
			touch_look_index = -1
	elif event is InputEventScreenDrag and event.index == touch_look_index and is_instance_valid(player):
		player.rotate_y(-event.relative.x * touch_look_sensitivity)
		player.pitch = clamp(player.pitch - event.relative.y * touch_look_sensitivity, -1.35, 1.35)
		if is_instance_valid(camera):
			camera.rotation.x = player.pitch

func _sync_network_pose(delta: float) -> void:
	if not _is_network_active() or not is_instance_valid(player):
		return
	network_pose_timer += delta
	if network_pose_timer < 0.08:
		return
	network_pose_timer = 0.0
	var pos := player.global_position
	if multiplayer.is_server():
		rpc("_rpc_remote_player_pose", multiplayer.get_unique_id(), pos, player.rotation.y, player.pitch)
	else:
		rpc_id(1, "_rpc_player_pose", pos, player.rotation.y, player.pitch)

func _recover_player_if_fallen() -> void:
	if not is_instance_valid(player) or player.global_position.y > -5.0:
		return
	player.global_position = Vector3(0.0, 1.0, end_z + current_room_length * 0.5)
	player.velocity = Vector3.ZERO

func _is_network_active() -> bool:
	return network_peer != null and network_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED

@rpc("any_peer", "call_remote", "unreliable")
func _rpc_player_pose(pos: Vector3, yaw: float, look_pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	_rpc_remote_player_pose(sender_id, pos, yaw, look_pitch)
	rpc("_rpc_remote_player_pose", sender_id, pos, yaw, look_pitch)

@rpc("authority", "call_remote", "unreliable")
func _rpc_remote_player_pose(peer_id: int, pos: Vector3, yaw: float, look_pitch: float) -> void:
	if peer_id == multiplayer.get_unique_id():
		return
	var avatar: Node3D = remote_players.get(peer_id)
	if not is_instance_valid(avatar):
		avatar = Node3D.new()
		avatar.name = "RemotePlayer_%d" % peer_id
		var mesh := MeshInstance3D.new()
		var capsule := CapsuleMesh.new()
		capsule.radius = 0.32
		capsule.height = 1.7
		mesh.mesh = capsule
		var material := StandardMaterial3D.new()
		material.albedo_color = Color(0.42, 0.68, 0.86)
		material.roughness = 0.78
		mesh.material_override = material
		avatar.add_child(mesh)
		add_child(avatar)
		remote_players[peer_id] = avatar
	avatar.global_position = pos
	avatar.rotation.y = yaw

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_state() -> void:
	if multiplayer.is_server():
		rpc_id(multiplayer.get_remote_sender_id(), "_rpc_sync_initial_state", door_number, health, money, bandages, weapon_ammo, searched_cabinets)

@rpc("authority", "call_remote", "reliable")
func _rpc_sync_initial_state(opened_doors: int, current_health: int, current_money: int, current_bandages: int, current_weapon_ammo: int, cabinet_state: Dictionary) -> void:
	rng.seed = MULTIPLAYER_WORLD_SEED
	if game_state == "menu":
		_start_singleplayer()
	for number in range(1, opened_doors + 1):
		_apply_door_open(number, false)
	health = current_health
	money = current_money
	bandages = current_bandages
	weapon_ammo = current_weapon_ammo
	searched_cabinets = cabinet_state.duplicate()
	for cabinet in cabinet_nodes:
		if is_instance_valid(cabinet):
			cabinet.set_meta("searched", searched_cabinets.has(int(cabinet.get_meta("room_id"))))
	if hud_health:
		hud_health.value = health
	_refresh_inventory()
	_refresh_hud_language()

func _on_peer_connected(peer_id: int) -> void:
	if multiplayer.is_server():
		rpc_id(peer_id, "_rpc_sync_initial_state", door_number, health, money, bandages, weapon_ammo, searched_cabinets)

func _on_peer_disconnected(peer_id: int) -> void:
	var avatar: Node = remote_players.get(peer_id)
	if is_instance_valid(avatar):
		avatar.queue_free()
	remote_players.erase(peer_id)

func _setup_input() -> void:
	for action in default_bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		_set_binding(action, default_bindings[action])

func _set_binding(action: String, keycode: int) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	InputMap.action_erase_events(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)

func _key_name(action: String) -> String:
	for ev in InputMap.action_get_events(action):
		if ev is InputEventKey:
			return OS.get_keycode_string(ev.physical_keycode)
	return "?"

func _make_interface() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	menu_root = Control.new()
	menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(menu_root)
	_build_menu_screen()
	_build_game_hud()
	_build_pause_overlay()
	_build_settings_overlay()

func _make_backdrop(parent: Control) -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.012, 0.009, 0.015, 1)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.add_child(bg)
	var glow := ColorRect.new()
	glow.color = Color(0.15, 0.075, 0.055, 0.22)
	glow.position = Vector2(620, 0)
	glow.size = Vector2(660, 720)
	parent.add_child(glow)

func _build_menu_screen() -> void:
	_make_backdrop(menu_root)
	var title := Label.new()
	title.text = "H A L L R O O M S"
	title.position = Vector2(74, 86)
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Color(0.94, 0.82, 0.67))
	menu_root.add_child(title)
	var sub := Label.new()
	sub.text = _tr("DU BIST NICHT ALLEIN.", "YOU ARE NOT ALONE.")
	sub.position = Vector2(82, 150)
	sub.add_theme_font_size_override("font_size", 15)
	sub.add_theme_color_override("font_color", Color(0.66, 0.57, 0.51))
	menu_root.add_child(sub)

	var buttons := VBoxContainer.new()
	buttons.position = Vector2(82, 265)
	buttons.size = Vector2(340, 360)
	buttons.add_theme_constant_override("separation", 14)
	menu_root.add_child(buttons)
	_menu_button(buttons, _tr("EINZELSPIELER", "SINGLEPLAYER"), _start_singleplayer)
	_menu_button(buttons, _tr("MEHRSPIELER", "MULTIPLAYER"), _open_multiplayer)
	_menu_button(buttons, _tr("MONSTER-INDEX", "MONSTER INDEX"), _open_monster_index)
	_menu_button(buttons, _tr("AUSSEHEN", "APPEARANCE"), _open_appearance)
	_menu_button(buttons, _tr("EINSTELLUNGEN", "SETTINGS"), _open_settings_from_menu)
	var version := Label.new()
	version.text = "HALLROOMS  •  VERSION 0.4.17"
	version.position = Vector2(82, 650)
	version.add_theme_font_size_override("font_size", 12)
	version.add_theme_color_override("font_color", Color(0.43, 0.39, 0.37))
	menu_root.add_child(version)

	preview_image = TextureRect.new()
	preview_image.texture = load(preview_paths[0])
	preview_image.position = Vector2(690, 90)
	preview_image.size = Vector2(500, 540)
	preview_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	preview_image.modulate = Color(1, 1, 1, 1)
	menu_root.add_child(preview_image)
	var name_tag := Label.new()
	name_tag.text = "BACKTERIUS 2.0  /  FLYMOUTH  /  HELIUS  /  DLHITE"
	name_tag.position = Vector2(695, 635)
	name_tag.size = Vector2(500, 30)
	name_tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_tag.add_theme_font_size_override("font_size", 13)
	name_tag.add_theme_color_override("font_color", Color(0.62, 0.53, 0.48))
	menu_root.add_child(name_tag)

func _menu_button(parent: VBoxContainer, text: String, callback: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(330, 58)
	b.add_theme_font_size_override("font_size", 20)
	b.add_theme_color_override("font_color", Color(0.94, 0.88, 0.81))
	b.add_theme_stylebox_override("normal", _style(Color(0.07, 0.05, 0.05, 0.94), Color(0.34, 0.23, 0.18)))
	b.add_theme_stylebox_override("hover", _style(Color(0.19, 0.10, 0.075, 0.98), Color(0.77, 0.49, 0.30)))
	b.pressed.connect(callback)
	parent.add_child(b)

func _style(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(8)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s

func _build_game_hud() -> void:
	game_hud = Control.new()
	game_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(game_hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(22, 20)
	panel.custom_minimum_size = Vector2(350, 176)
	panel.add_theme_stylebox_override("panel", _style(Color(0.025, 0.02, 0.025, 0.84), Color(0.42, 0.31, 0.23)))
	game_hud.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	panel.add_child(col)
	door_text = Label.new()
	door_text.add_theme_font_size_override("font_size", 22)
	door_text.add_theme_color_override("font_color", Color(0.95, 0.84, 0.68))
	col.add_child(door_text)
	objective_text = Label.new()
	objective_text.add_theme_font_size_override("font_size", 13)
	objective_text.add_theme_color_override("font_color", Color(0.82, 0.78, 0.71))
	objective_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective_text.custom_minimum_size = Vector2(310, 32)
	col.add_child(objective_text)
	var row := HBoxContainer.new()
	col.add_child(row)
	var heart := Label.new()
	heart.text = "♥"
	heart.add_theme_font_size_override("font_size", 22)
	heart.add_theme_color_override("font_color", Color(0.85, 0.20, 0.22))
	row.add_child(heart)
	hud_health = ProgressBar.new()
	hud_health.custom_minimum_size = Vector2(235, 22)
	hud_health.max_value = 100
	hud_health.value = 100
	hud_health.show_percentage = false
	row.add_child(hud_health)
	health_text = Label.new()
	health_text.add_theme_font_size_override("font_size", 14)
	health_text.add_theme_color_override("font_color", Color(0.95, 0.88, 0.82))
	col.add_child(health_text)
	inventory_text = Label.new()
	inventory_text.add_theme_font_size_override("font_size", 14)
	inventory_text.add_theme_color_override("font_color", Color(0.90, 0.78, 0.58))
	col.add_child(inventory_text)
	hint_text = Label.new()
	hint_text.anchor_left = 0.5
	hint_text.anchor_right = 0.5
	hint_text.anchor_top = 0.89
	hint_text.anchor_bottom = 0.89
	hint_text.offset_left = -260
	hint_text.offset_right = 260
	hint_text.add_theme_font_size_override("font_size", 19)
	hint_text.add_theme_color_override("font_color", Color(0.97, 0.91, 0.83))
	hint_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	game_hud.add_child(hint_text)
	alert_text = Label.new()
	alert_text.anchor_left = 0.5
	alert_text.anchor_right = 0.5
	alert_text.anchor_top = 0.16
	alert_text.anchor_bottom = 0.16
	alert_text.offset_left = -300
	alert_text.offset_right = 300
	alert_text.add_theme_font_size_override("font_size", 23)
	alert_text.add_theme_color_override("font_color", Color(1, 0.35, 0.25))
	alert_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	game_hud.add_child(alert_text)
	game_hud.visible = false
	if mobile_controls:
		_add_mobile_controls()

func _add_mobile_controls() -> void:
	var controls := Control.new()
	controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	controls.mouse_filter = Control.MOUSE_FILTER_IGNORE
	game_hud.add_child(controls)
	var specs := [
		["move_forward", "▲", Vector2(112, -176)],
		["move_back", "▼", Vector2(112, -64)],
		["move_left", "◀", Vector2(56, -120)],
		["move_right", "▶", Vector2(168, -120)],
		["sprint", "RUN", Vector2(272, -120)],
	]
	for spec in specs:
		var action: String = spec[0]
		var button := Button.new()
		button.text = spec[1]
		button.anchor_left = 0.0
		button.anchor_right = button.anchor_left
		button.anchor_top = 1.0
		button.anchor_bottom = 1.0
		button.offset_left = spec[2].x - 48
		button.offset_right = spec[2].x + 48
		button.offset_top = spec[2].y - 48
		button.offset_bottom = spec[2].y + 48
		button.add_theme_font_size_override("font_size", 20)
		button.modulate = Color(1, 1, 1, 0.78)
		button.button_down.connect(func(): Input.action_press(action))
		button.button_up.connect(func(): Input.action_release(action))
		controls.add_child(button)
	var interact_button := _make_touch_button(controls, _tr("ÖFFNEN", "OPEN"), Vector2(1.0, 1.0), Vector2(-186, -126), Vector2(92, 72))
	interact_button.pressed.connect(func(): Input.action_press("interact"))
	interact_button.button_up.connect(func(): Input.action_release("interact"))
	var bandage_button := _make_touch_button(controls, _tr("VERBAND", "HEAL"), Vector2(1.0, 1.0), Vector2(-320, -126), Vector2(86, 72))
	bandage_button.button_down.connect(func(): Input.action_press("use_bandage"))
	bandage_button.button_up.connect(func(): Input.action_release("use_bandage"))
	var weapon_button := _make_touch_button(controls, _tr("FEUER", "FIRE"), Vector2(1.0, 1.0), Vector2(-430, -126), Vector2(86, 72))
	weapon_button.pressed.connect(_fire_weapon)
	var pause_button := _make_touch_button(controls, _tr("Ⅱ", "Ⅱ"), Vector2(1.0, 0.0), Vector2(-82, 24), Vector2(58, 58))
	pause_button.pressed.connect(_pause_game)

func _make_touch_button(parent: Control, text_value: String, anchor: Vector2, offset: Vector2, size: Vector2) -> Button:
	var button := Button.new()
	button.text = text_value
	button.anchor_left = anchor.x
	button.anchor_right = anchor.x
	button.anchor_top = anchor.y
	button.anchor_bottom = anchor.y
	button.offset_left = offset.x - size.x * 0.5
	button.offset_right = offset.x + size.x * 0.5
	button.offset_top = offset.y - size.y * 0.5
	button.offset_bottom = offset.y + size.y * 0.5
	button.add_theme_font_size_override("font_size", 17)
	button.modulate = Color(1, 1, 1, 0.82)
	parent.add_child(button)
	return button

func _build_pause_overlay() -> void:
	pause_overlay = ColorRect.new()
	pause_overlay.color = Color(0, 0, 0, 0.78)
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_overlay.visible = false
	ui_layer.add_child(pause_overlay)
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-205, -205)
	panel.custom_minimum_size = Vector2(410, 410)
	panel.add_theme_stylebox_override("panel", _style(Color(0.045, 0.035, 0.04, 0.99), Color(0.58, 0.37, 0.27)))
	pause_overlay.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 13)
	panel.add_child(col)
	var title := Label.new()
	title.text = "H A L L R O O M S"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color(0.95, 0.82, 0.65))
	col.add_child(title)
	_menu_button(col, _tr("WEITERSPIELEN", "RESUME"), _resume_game)
	_menu_button(col, _tr("EINSTELLUNGEN", "SETTINGS"), _open_settings_from_pause)
	_menu_button(col, _tr("HAUPTMENÜ", "MAIN MENU"), _return_to_menu)
	_menu_button(col, _tr("BEENDEN", "QUIT"), _quit_game)

func _build_settings_overlay() -> void:
	settings_overlay = ColorRect.new()
	settings_overlay.color = Color(0, 0, 0, 0.86)
	settings_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_overlay.visible = false
	ui_layer.add_child(settings_overlay)
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-290, -315)
	panel.custom_minimum_size = Vector2(580, 630)
	panel.add_theme_stylebox_override("panel", _style(Color(0.045, 0.035, 0.04, 0.99), Color(0.58, 0.37, 0.27)))
	settings_overlay.add_child(panel)
	settings_container = VBoxContainer.new()
	settings_container.add_theme_constant_override("separation", 9)
	panel.add_child(settings_container)
	_rebuild_settings()

func _rebuild_settings() -> void:
	for child in settings_container.get_children():
		child.queue_free()
	binding_buttons.clear()
	var title := Label.new()
	title.text = _tr("EINSTELLUNGEN", "SETTINGS")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 27)
	title.add_theme_color_override("font_color", Color(0.95, 0.82, 0.65))
	settings_container.add_child(title)

	var lang := OptionButton.new()
	lang.add_item("Deutsch")
	lang.add_item("English")
	lang.selected = 0 if current_language == "de" else 1
	lang.item_selected.connect(_on_language_selected)
	settings_container.add_child(_labeled_control(_tr("SPRACHE", "LANGUAGE"), lang))

	var hud_check := CheckButton.new()
	hud_check.text = _tr("Lebensleiste und HUD anzeigen", "Show health bar and HUD")
	hud_check.button_pressed = hud_enabled
	hud_check.toggled.connect(_on_hud_toggled)
	settings_container.add_child(hud_check)

	var scale := HSlider.new()
	scale.min_value = 0.75
	scale.max_value = 1.35
	scale.step = 0.05
	scale.value = ui_scale
	scale.value_changed.connect(_on_ui_scale)
	settings_container.add_child(_labeled_control(_tr("UI-GRÖSSE", "UI SCALE"), scale))
	var quality := OptionButton.new()
	quality.add_item(_tr("Niedrig", "Low"))
	quality.add_item(_tr("Mittel", "Medium"))
	quality.add_item(_tr("Hoch", "High"))
	quality.selected = graphics_quality
	quality.item_selected.connect(_on_graphics_quality_selected)
	settings_container.add_child(_labeled_control(_tr("GRAFIKDETAILS", "GRAPHICS QUALITY"), quality))

	var sens := HSlider.new()
	sens.min_value = 0.5
	sens.max_value = 3.0
	sens.step = 0.1
	sens.value = sensitivity_multiplier
	sens.value_changed.connect(_on_sensitivity)
	settings_container.add_child(_labeled_control(_tr("KAMERA-EMPFINDLICHKEIT", "LOOK SENSITIVITY"), sens))
	if mobile_controls:
		var touch_hint := Label.new()
		touch_hint.text = _tr("Steuerung: Pfeile und RUN links, ÖFFNEN/VERBAND/FEUER rechts. Rechts wischen bewegt die Kamera.", "Controls: arrows and RUN left, OPEN/HEAL/FIRE right. Swipe on the right to look around.")
		touch_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		settings_container.add_child(touch_hint)
	else:
		var keys_title := Label.new()
		keys_title.text = _tr("TASTENBELEGUNG", "KEY BINDINGS")
		keys_title.add_theme_color_override("font_color", Color(0.82, 0.55, 0.38))
		settings_container.add_child(keys_title)
		for action in binding_names:
			var row := HBoxContainer.new()
			var label := Label.new()
			label.text = binding_names[action][0 if current_language == "de" else 1]
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(label)
			var button := Button.new()
			button.custom_minimum_size = Vector2(120, 32)
			button.text = _key_name(action)
			button.pressed.connect(_begin_rebind.bind(action))
			row.add_child(button)
			binding_buttons[action] = button
			settings_container.add_child(row)
		var hint := Label.new()
		hint.name = "KeyHint"
		hint.text = _tr("Taste anklicken und neue Taste drücken. ESC bricht ab.", "Click a key and press its new key. ESC cancels.")
		hint.add_theme_font_size_override("font_size", 11)
		hint.add_theme_color_override("font_color", Color(0.70, 0.65, 0.60))
		settings_container.add_child(hint)
	var back := Button.new()
	back.text = _tr("ZURÜCK", "BACK")
	back.custom_minimum_size.y = 42
	back.pressed.connect(_close_settings)
	settings_container.add_child(back)

func _labeled_control(label_text: String, control: Control) -> Control:
	var box := VBoxContainer.new()
	var label := Label.new()
	label.text = label_text
	label.add_theme_color_override("font_color", Color(0.80, 0.73, 0.66))
	box.add_child(label)
	box.add_child(control)
	return box

func _begin_rebind(action: String) -> void:
	waiting_for_key = action
	var hint := settings_container.find_child("KeyHint", true, false)
	if hint:
		hint.text = _tr("Drücke jetzt eine Taste für: ", "Press a key for: ") + binding_names[action][0 if current_language == "de" else 1]

func _refresh_binding_buttons() -> void:
	for action in binding_buttons:
		binding_buttons[action].text = _key_name(action)
	var hint := settings_container.find_child("KeyHint", true, false)
	if hint:
		hint.text = _tr("Taste anklicken und neue Taste drücken. ESC bricht ab.", "Click a key and press its new key. ESC cancels.")

func _on_language_selected(index: int) -> void:
	current_language = "de" if index == 0 else "en"
	_rebuild_settings()
	_refresh_hud_language()
	# Rebuild menu labels too when changing language.
	for child in menu_root.get_children():
		child.queue_free()
	_build_menu_screen()

func _on_hud_toggled(value: bool) -> void:
	hud_enabled = value
	game_hud.visible = value and game_state == "playing"

func _on_ui_scale(value: float) -> void:
	ui_scale = value
	game_hud.scale = Vector2(value, value)

func _on_graphics_quality_selected(index: int) -> void:
	graphics_quality = clampi(index, 0, 2)
	_apply_graphics_quality()
	_save_user_settings()

func _load_user_settings() -> void:
	var config := ConfigFile.new()
	if config.load("user://settings.cfg") == OK:
		graphics_quality = clampi(int(config.get_value("graphics", "quality", 2)), 0, 2)

func _save_user_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("graphics", "quality", graphics_quality)
	config.save("user://settings.cfg")

func _apply_graphics_quality() -> void:
	if is_instance_valid(game_environment):
		game_environment.ambient_light_energy = [0.58, 0.78, 0.96][graphics_quality]
	for light in light_nodes:
		if not is_instance_valid(light):
			continue
		var minimum_quality := int(light.get_meta("minimum_quality", 0))
		light.visible = graphics_quality >= minimum_quality
		light.shadow_enabled = graphics_quality >= 2
		if light.has_meta("normal_energy"):
			light.light_energy = float(light.get_meta("normal_energy"))

func _on_sensitivity(value: float) -> void:
	sensitivity_multiplier = value
	touch_look_sensitivity = 0.004 * value
	if player:
		player.mouse_sensitivity = 0.0022 * value

func _load_monster_index() -> void:
	var config := ConfigFile.new()
	if config.load("user://monster_index.cfg") == OK:
		for kind in MONSTER_ORDER:
			monster_seen[kind] = bool(config.get_value("seen", kind, false))

func _save_monster_index() -> void:
	var config := ConfigFile.new()
	for kind in MONSTER_ORDER:
		config.set_value("seen", kind, bool(monster_seen.get(kind, false)))
	config.save("user://monster_index.cfg")

func _mark_monster_seen(kind: String) -> void:
	if not monster_seen.has(kind) or bool(monster_seen[kind]):
		return
	monster_seen[kind] = true
	_save_monster_index()

func _monster_texture_path(kind: String) -> String:
	match kind:
		"Backterius 2.0":
			return "res://assets/monsters/backterius.svg"
		"Helius":
			return "res://assets/monsters/helius.svg"
		"Dlhite":
			return "res://assets/monsters/dlhite.png"
		"Boss1":
			return "res://assets/monsters/boss1.png"
		_:
			return "res://assets/monsters/flymouth.svg"

func _open_monster_index() -> void:
	if is_instance_valid(index_dialog):
		index_dialog.queue_free()
	index_dialog = AcceptDialog.new()
	index_dialog.title = _tr("Monster-Index", "Monster Index")
	index_dialog.dialog_text = _tr("Ein Eintrag wird freigeschaltet, sobald du das Monster zum ersten Mal wirklich siehst.", "An entry unlocks the first time you actually see that monster.")
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(600, 360)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	for kind in MONSTER_ORDER:
		var unlocked := bool(monster_seen.get(kind, false))
		var card := PanelContainer.new()
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var picture := TextureRect.new()
		picture.custom_minimum_size = Vector2(88, 88)
		picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		if unlocked:
			picture.texture = load(_monster_texture_path(kind))
		row.add_child(picture)
		var text_column := VBoxContainer.new()
		text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var name_label := Label.new()
		name_label.text = kind if unlocked else "???"
		name_label.add_theme_font_size_override("font_size", 20)
		name_label.add_theme_color_override("font_color", Color(0.95, 0.82, 0.65))
		text_column.add_child(name_label)
		var description := Label.new()
		description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		description.text = MONSTER_DESCRIPTIONS[kind][0 if current_language == "de" else 1] if unlocked else _tr("Noch nicht entdeckt.", "Not discovered yet.")
		text_column.add_child(description)
		row.add_child(text_column)
		card.add_child(row)
		list.add_child(card)
	scroll.add_child(list)
	index_dialog.add_child(scroll)
	add_child(index_dialog)
	index_dialog.confirmed.connect(index_dialog.queue_free)
	index_dialog.canceled.connect(index_dialog.queue_free)
	index_dialog.popup_centered(Vector2i(720, 520))

func _show_main_menu() -> void:
	game_state = "menu"
	menu_root.visible = true
	game_hud.visible = false
	pause_overlay.visible = false
	settings_overlay.visible = false
	preview_timer = 0.0
	preview_index = 0
	if preview_image:
		preview_image.texture = load(preview_paths[0])
		preview_image.modulate.a = 1.0
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _start_singleplayer() -> void:
	menu_root.visible = false
	_clear_game_world()
	health = 100
	money = 0
	bandages = 0
	weapon_ammo = 0
	watched_dlhite_id = 0
	dlhite_watch_time = 0.0
	searched_cabinets.clear()
	scream_machines.clear()
	boss_maze_openings.clear()
	boss_health = 250
	boss_hits_taken = 0
	boss_defeated = false
	room34_bonus_awarded = false
	door_number = 0
	end_z = 0.0
	room_index = 0
	if _is_network_active():
		rng.seed = MULTIPLAYER_WORLD_SEED
	else:
		rng.randomize()
	door_nodes.clear()
	cabinet_nodes.clear()
	shop_node = null
	light_nodes.clear()
	_make_environment()
	_make_player()
	_build_room()
	_refresh_hud_language()
	game_state = "playing"
	game_hud.visible = hud_enabled
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_spawn_room_encounter()

func _clear_game_world() -> void:
	if player and is_instance_valid(player):
		player.queue_free()
	player = null
	remote_players.clear()
	cabinet_nodes.clear()
	monster_nodes.clear()
	scream_machines.clear()
	boss_maze_openings.clear()
	shop_node = null
	room_roots.clear()
	light_nodes.clear()
	game_environment = null
	for child in get_children():
		if child != ui_layer:
			child.queue_free()

func _make_environment() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.008, 0.006, 0.01)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.48, 0.41, 0.36)
	env.ambient_light_energy = 0.82
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	game_environment = env
	env_node.environment = env
	add_child(env_node)
	_apply_graphics_quality()

func _make_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.set_script(PLAYER_SCRIPT)
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	player.position = Vector3(0, 0.95, -2.5)
	camera = Camera3D.new()
	camera.name = "Camera3D"
	camera.position = Vector3(0, 0.62, 0)
	camera.current = true
	camera.fov = 78
	player.add_child(camera)
	add_child(player)
	player.mouse_sensitivity = 0.0022 * sensitivity_multiplier

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.9
	return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, material: Material, collision := true) -> void:
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	mesh.position = pos
	mesh.material_override = material
	parent.add_child(mesh)
	if collision:
		var body := StaticBody3D.new()
		body.position = pos
		var shape := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		shape.shape = bs
		body.add_child(shape)
		parent.add_child(body)

func _build_room() -> void:
	room_index += 1
	var room_root := Node3D.new()
	room_root.name = "Room_%02d" % room_index
	room_root.set_meta("start_z", end_z)
	room_root.set_meta("rear_sealed", room_index == 1)
	add_child(room_root)
	room_roots.append(room_root)
	if room_roots.size() > 3:
		var expired_room: Node3D = room_roots.pop_front() as Node3D
		if not room_roots.is_empty() and not room_roots[0].get_meta("rear_sealed", false):
			var kept_room := room_roots[0]
			var kept_width := float(kept_room.get_meta("width", 10.0))
			var kept_start := float(kept_room.get_meta("start_z", 0.0))
			_box(kept_room, Vector3(kept_width, 4.6, 0.3), Vector3(0, 2.0, kept_start + 0.15), _mat(Color(0.36, 0.31, 0.29)))
			kept_room.set_meta("rear_sealed", true)
		for i in range(light_nodes.size() - 1, -1, -1):
			if is_instance_valid(light_nodes[i]) and light_nodes[i].get_parent() == expired_room:
				light_nodes.remove_at(i)
		expired_room.queue_free()
		for old_door in door_nodes:
			if is_instance_valid(old_door) and int(old_door.get_meta("number", 999)) <= room_index - 3:
				old_door.visible = false
				var old_collision := old_door.find_child("DoorCollision", true, false) as CollisionShape3D
				if is_instance_valid(old_collision):
					old_collision.disabled = true
	var width: float = 32.0 if room_index == 35 else rng.randf_range(8.5, 14.0)
	var length: float = 36.0 if room_index == 35 else rng.randf_range(11.0, 19.0)
	room_root.set_meta("width", width)
	current_room_width = width
	current_room_length = length
	var start := end_z
	var finish := start - length
	var center_z := (start + finish) * 0.5
	var floor_mat := _mat(Color(0.29 + rng.randf() * 0.035, 0.25, 0.23))
	var wall_mat := _mat(Color(0.36, 0.31, 0.29))
	var trim_mat := _mat(Color(0.09, 0.065, 0.05))
	var ceiling_mat := _mat(Color(0.16, 0.13, 0.12))
	# Overlap the floors beyond both thresholds so there is never a gap while the next room loads.
	_box(room_root, Vector3(width, 0.35, length + 6.0), Vector3(0, -0.2, center_z), floor_mat)
	_box(room_root, Vector3(0.3, 4.6, length), Vector3(-width * 0.5, 2.0, center_z), wall_mat)
	_box(room_root, Vector3(0.3, 4.6, length), Vector3(width * 0.5, 2.0, center_z), wall_mat)
	_box(room_root, Vector3(width, 0.25, length), Vector3(0, 4.25, center_z), ceiling_mat)
	# Enclose the rear of the first room; later rooms retain an opening for the door just passed.
	var wall_depth := 0.3
	if room_index == 1:
		_box(room_root, Vector3(width, 4.6, wall_depth), Vector3(0, 2.0, start + wall_depth * 0.5), wall_mat)
	else:
		var doorway_width := 2.45
		var side_width := (width - doorway_width) * 0.5
		_box(room_root, Vector3(side_width, 4.6, wall_depth), Vector3(-(doorway_width + side_width) * 0.5, 2.0, start + wall_depth * 0.5), wall_mat)
		_box(room_root, Vector3(side_width, 4.6, wall_depth), Vector3((doorway_width + side_width) * 0.5, 2.0, start + wall_depth * 0.5), wall_mat)
		_box(room_root, Vector3(doorway_width, 1.25, wall_depth), Vector3(0, 3.625, start + wall_depth * 0.5), wall_mat)
	# The exit is also a wall with a door-sized opening; this stops players escaping around the door.
	var exit_width := 2.45
	var exit_side_width := (width - exit_width) * 0.5
	_box(room_root, Vector3(exit_side_width, 4.6, wall_depth), Vector3(-(exit_width + exit_side_width) * 0.5, 2.0, finish - wall_depth * 0.5), wall_mat)
	_box(room_root, Vector3(exit_side_width, 4.6, wall_depth), Vector3((exit_width + exit_side_width) * 0.5, 2.0, finish - wall_depth * 0.5), wall_mat)
	_box(room_root, Vector3(exit_width, 1.25, wall_depth), Vector3(0, 3.625, finish - wall_depth * 0.5), wall_mat)
	for side in [-1.0, 1.0]:
		_box(room_root, Vector3(0.1, 0.16, length - 0.2), Vector3(side * (width * 0.5 - 0.19), 0.15, center_z), trim_mat, false)
	# Layered wainscoting, framed panels, and warm wall sconces give each corridor depth.
	var wood := _mat(Color(0.20, 0.12, 0.085))
	var inset := _mat(Color(0.31, 0.23, 0.19))
	var brass := _mat(Color(0.58, 0.37, 0.16))
	for side in [-1.0, 1.0]:
		var wall_x: float = side * (width * 0.5 - 0.17)
		_box(room_root, Vector3(0.10, 0.24, length - 0.3), Vector3(wall_x, 0.35, center_z), wood, false)
		_box(room_root, Vector3(0.10, 0.10, length - 0.3), Vector3(wall_x, 1.05, center_z), brass, false)
		_box(room_root, Vector3(0.10, 0.11, length - 0.3), Vector3(wall_x, 2.95, center_z), wood, false)
		for i in range(2):
			var panel_z := start - length * (float(i) + 0.5) / 2.0
			_box(room_root, Vector3(0.045, 1.35, 1.65), Vector3(wall_x, 1.95, panel_z), inset, false)
			for rail_y in [1.28, 2.62]:
				_box(room_root, Vector3(0.065, 0.055, 1.82), Vector3(wall_x - side * 0.018, rail_y, panel_z), brass, false)
			if i == 0:
				var fixture := MeshInstance3D.new()
				var fixture_mesh := BoxMesh.new()
				fixture_mesh.size = Vector3(0.18, 0.38, 0.22)
				fixture.mesh = fixture_mesh
				fixture.position = Vector3(wall_x - side * 0.12, 2.85, panel_z)
				fixture.material_override = brass
				room_root.add_child(fixture)
				var sconce := OmniLight3D.new()
				sconce.position = fixture.position + Vector3(-side * 0.14, -0.12, 0)
				sconce.light_color = Color(1.0, 0.68, 0.38)
				sconce.light_energy = 1.15
				sconce.omni_range = 5.5
				sconce.set_meta("normal_energy", 1.15)
				sconce.set_meta("minimum_quality", 1)
				sconce.visible = graphics_quality >= int(sconce.get_meta("minimum_quality"))
				room_root.add_child(sconce)
				light_nodes.append(sconce)
	if room_index == 35:
		_build_boss_labyrinth(room_root, start, length)
	var lamp := OmniLight3D.new()
	lamp.position = Vector3(0, 3.55, center_z)
	lamp.light_color = Color(1.0, 0.78, 0.57)
	lamp.light_energy = rng.randf_range(2.6, 3.4)
	lamp.omni_range = maxf(width * 1.15, 14.0)
	lamp.set_meta("normal_energy", lamp.light_energy)
	lamp.set_meta("minimum_quality", 0)
	lamp.shadow_enabled = graphics_quality >= 2
	room_root.add_child(lamp)
	light_nodes.append(lamp)
	_make_door(room_index, finish)
	if room_index == 14 or room_index == 34:
		_make_shop(room_root, width, center_z)
	elif room_index % 4 == 0:
		_make_cabinet(width, center_z)
	end_z = finish
	_apply_graphics_quality()

func _build_boss_labyrinth(parent: Node3D, start_z: float, length: float) -> void:
	var maze_wall := _mat(Color(0.19, 0.17, 0.17))
	var thickness := 0.24
	var cell := BOSS_MAZE_CELL_SIZE
	var span_x := float(BOSS_MAZE_COLUMNS) * cell
	var span_z := float(BOSS_MAZE_ROWS) * cell
	boss_maze_origin_x = -span_x * 0.5
	var margin_z := (length - span_z) * 0.5
	boss_maze_origin_z = start_z - margin_z
	boss_maze_openings.clear()
	for row in range(BOSS_MAZE_ROWS):
		var row_data: Array = []
		for col in range(BOSS_MAZE_COLUMNS):
			row_data.append({"left": false, "right": false, "up": false, "down": false})
		boss_maze_openings.append(row_data)
	var visited: Dictionary = {}
	var stack: Array[Vector2i] = [Vector2i(3, 0)]
	visited["3,0"] = true
	while not stack.is_empty():
		var current: Vector2i = stack.back()
		var choices: Array[Vector2i] = []
		for candidate_direction in [Vector2i(0, -1), Vector2i(1, 0), Vector2i(0, 1), Vector2i(-1, 0)]:
			var next_cell: Vector2i = current + candidate_direction
			if next_cell.x >= 0 and next_cell.x < BOSS_MAZE_COLUMNS and next_cell.y >= 0 and next_cell.y < BOSS_MAZE_ROWS and not visited.has("%d,%d" % [next_cell.x, next_cell.y]):
				choices.append(candidate_direction)
		if choices.is_empty():
			stack.pop_back()
			continue
		var chosen_direction: Vector2i = choices[rng.randi_range(0, choices.size() - 1)]
		var next_cell: Vector2i = current + chosen_direction
		var from_open: Dictionary = boss_maze_openings[current.y][current.x]
		var to_open: Dictionary = boss_maze_openings[next_cell.y][next_cell.x]
		if chosen_direction == Vector2i(0, -1):
			from_open["up"] = true
			to_open["down"] = true
		elif chosen_direction == Vector2i(1, 0):
			from_open["right"] = true
			to_open["left"] = true
		elif chosen_direction == Vector2i(0, 1):
			from_open["down"] = true
			to_open["up"] = true
		else:
			from_open["left"] = true
			to_open["right"] = true
		boss_maze_openings[current.y][current.x] = from_open
		boss_maze_openings[next_cell.y][next_cell.x] = to_open
		visited["%d,%d" % [next_cell.x, next_cell.y]] = true
		stack.append(next_cell)
	for row in range(BOSS_MAZE_ROWS):
		for col in range(BOSS_MAZE_COLUMNS):
			var center_x := boss_maze_origin_x + (float(col) + 0.5) * cell
			var center_z := boss_maze_origin_z - (float(row) + 0.5) * cell
			var openings: Dictionary = boss_maze_openings[row][col]
			if col < BOSS_MAZE_COLUMNS - 1 and not bool(openings["right"]):
				_box(parent, Vector3(thickness, 2.8, cell), Vector3(center_x + cell * 0.5, 1.4, center_z), maze_wall)
			if row < BOSS_MAZE_ROWS - 1 and not bool(openings["down"]):
				_box(parent, Vector3(cell, 2.8, thickness), Vector3(center_x, 1.4, center_z - cell * 0.5), maze_wall)
	# Dark red lamps make the branching passages readable without exposing the whole maze.
	for cell_value in [Vector2i(1, 1), Vector2i(5, 1), Vector2i(1, 5), Vector2i(5, 5)]:
		var cell_pos: Vector2i = cell_value
		var x := boss_maze_origin_x + (float(cell_pos.x) + 0.5) * cell
		var z := boss_maze_origin_z - (float(cell_pos.y) + 0.5) * cell
		var glimmer := OmniLight3D.new()
		glimmer.position = Vector3(x, 2.5, z)
		glimmer.light_color = Color(0.72, 0.16, 0.11)
		glimmer.light_energy = 0.8
		glimmer.omni_range = 4.8
		glimmer.set_meta("normal_energy", 0.8)
		parent.add_child(glimmer)
		light_nodes.append(glimmer)
	var candidates: Array[Vector2i] = []
	for row in range(BOSS_MAZE_ROWS):
		for col in range(BOSS_MAZE_COLUMNS):
			var c := Vector2i(col, row)
			if c != Vector2i(3, 0) and c != Vector2i(3, 6) and c != Vector2i(6, 6):
				candidates.append(c)
	for number in range(1, 6):
		var pick := rng.randi_range(0, candidates.size() - 1)
		var machine_cell: Vector2i = candidates.pop_at(pick)
		_make_scream_machine(parent, machine_cell, number)

func _make_scream_machine(parent: Node3D, cell_pos: Vector2i, number: int) -> void:
	var machine := Node3D.new()
	machine.name = "ScreamMachine_%d" % number
	machine.position = Vector3(boss_maze_origin_x + (float(cell_pos.x) + 0.5) * BOSS_MAZE_CELL_SIZE + 0.95, 0.0, boss_maze_origin_z - (float(cell_pos.y) + 0.5) * BOSS_MAZE_CELL_SIZE)
	machine.set_meta("machine_number", number)
	machine.set_meta("activated", false)
	_box(machine, Vector3(0.75, 1.7, 0.55), Vector3(0, 0.85, 0), _mat(Color(0.12, 0.14, 0.15)))
	_box(machine, Vector3(0.57, 0.55, 0.08), Vector3(0, 1.35, -0.31), _mat(Color(0.55, 0.035, 0.025)))
	_box(machine, Vector3(0.68, 0.12, 0.45), Vector3(0, 1.78, 0), _mat(Color(0.33, 0.30, 0.26)), false)
	var label := Label3D.new()
	label.text = _tr("MASCHINE %d\nHIER REINSCHREIEN" % number, "MACHINE %d\nSCREAM HERE" % number)
	label.position = Vector3(0, 2.18, -0.05)
	label.font_size = 28
	label.modulate = Color(1.0, 0.72, 0.48)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	machine.add_child(label)
	parent.add_child(machine)
	scream_machines.append(machine)

func _boss_cell_center(cell_pos: Vector2i) -> Vector3:
	return Vector3(boss_maze_origin_x + (float(cell_pos.x) + 0.5) * BOSS_MAZE_CELL_SIZE, 0.0, boss_maze_origin_z - (float(cell_pos.y) + 0.5) * BOSS_MAZE_CELL_SIZE)

func _boss_cell_for_world(pos: Vector3) -> Vector2i:
	var col := clampi(floori((pos.x - boss_maze_origin_x) / BOSS_MAZE_CELL_SIZE), 0, BOSS_MAZE_COLUMNS - 1)
	var row := clampi(floori((boss_maze_origin_z - pos.z) / BOSS_MAZE_CELL_SIZE), 0, BOSS_MAZE_ROWS - 1)
	return Vector2i(col, row)

func get_boss_chase_target(from_pos: Vector3, to_pos: Vector3) -> Vector3:
	if boss_maze_openings.size() != BOSS_MAZE_ROWS:
		return to_pos
	var start_cell := _boss_cell_for_world(from_pos)
	var target_cell := _boss_cell_for_world(to_pos)
	if start_cell == target_cell:
		return to_pos
	var queue: Array[Vector2i] = [start_cell]
	var parents: Dictionary = {"%d,%d" % [start_cell.x, start_cell.y]: ""}
	var index := 0
	while index < queue.size():
		var current: Vector2i = queue[index]
		index += 1
		if current == target_cell:
			break
		var openings: Dictionary = boss_maze_openings[current.y][current.x]
		for direction in [Vector2i(0, -1), Vector2i(1, 0), Vector2i(0, 1), Vector2i(-1, 0)]:
			var key := "up" if direction == Vector2i(0, -1) else "right" if direction == Vector2i(1, 0) else "down" if direction == Vector2i(0, 1) else "left"
			var neighbor: Vector2i = current + direction
			var neighbor_key := "%d,%d" % [neighbor.x, neighbor.y]
			if bool(openings[key]) and not parents.has(neighbor_key):
				parents[neighbor_key] = "%d,%d" % [current.x, current.y]
				queue.append(neighbor)
	var step := target_cell
	while str(parents.get("%d,%d" % [step.x, step.y], "")) != "%d,%d" % [start_cell.x, start_cell.y]:
		var previous := str(parents.get("%d,%d" % [step.x, step.y], ""))
		if previous == "":
			return _boss_cell_center(start_cell)
		var coords := previous.split(",")
		step = Vector2i(int(coords[0]), int(coords[1]))
	return _boss_cell_center(step)

func _make_cabinet(width: float, center_z: float) -> void:
	var cabinet := Node3D.new()
	cabinet.name = "CabinetRoom_%d" % room_index
	cabinet.position = Vector3(-width * 0.5 + 1.0, 0.0, center_z - 1.0)
	cabinet.scale = Vector3.ONE * 2.1
	cabinet.set_meta("room_id", room_index)
	cabinet.set_meta("searched", searched_cabinets.has(room_index))
	var model := MeshInstance3D.new()
	model.mesh = load("res://assets/furniture/Schrank.obj") as Mesh
	cabinet.add_child(model)
	var obstacle := StaticBody3D.new()
	obstacle.position.y = 0.28125
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(0.31, 0.5625, 0.31)
	shape.shape = box
	obstacle.add_child(shape)
	cabinet.add_child(obstacle)
	if not room_roots.is_empty():
		room_roots.back().add_child(cabinet)
	else:
		add_child(cabinet)
	cabinet_nodes.append(cabinet)

func _make_shop(parent: Node3D, width: float, center_z: float) -> void:
	var shop := Node3D.new()
	shop.name = "BandageShop_Room%d" % room_index
	shop.position = Vector3(width * 0.5 - 1.65, 0.0, center_z)
	shop.set_meta("room_id", room_index)
	_box(shop, Vector3(1.8, 1.0, 0.9), Vector3(0, 0.5, 0), _mat(Color(0.23, 0.13, 0.075)), true)
	_box(shop, Vector3(1.92, 0.12, 1.0), Vector3(0, 1.05, 0), _mat(Color(0.48, 0.30, 0.15)), false)
	var sign := Label3D.new()
	sign.text = _tr("SHOP\n+20 $\nVERBAND $5\nWAFFE $10", "SHOP\n+$20\nBANDAGE $5\nWEAPON $10") if room_index == 34 else _tr("SHOP\nVERBAND $5\nWAFFE $10", "SHOP\nBANDAGE $5\nWEAPON $10")
	sign.position = Vector3(0, 2.0, -0.52)
	sign.font_size = 42
	sign.modulate = Color(0.98, 0.80, 0.45)
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	shop.add_child(sign)
	parent.add_child(shop)
	shop_node = shop

func _make_door(number: int, z: float) -> void:
	var door := Node3D.new()
	door.name = "Door_%03d" % number
	door.position = Vector3(0, 1.45, z)
	door.set_meta("number", number)
	door.set_meta("opened", false)
	add_child(door)
	_box(door, Vector3(0.18, 3.1, 0.34), Vector3(-1.13, 0, 0), _mat(Color(0.075, 0.045, 0.03)), false)
	_box(door, Vector3(0.18, 3.1, 0.34), Vector3(1.13, 0, 0), _mat(Color(0.075, 0.045, 0.03)), false)
	_box(door, Vector3(2.44, 0.18, 0.34), Vector3(0, 1.46, 0), _mat(Color(0.075, 0.045, 0.03)), false)
	var leaf := Node3D.new()
	leaf.name = "DoorLeaf"
	leaf.position.x = -1.05
	door.add_child(leaf)
	_box(leaf, Vector3(2.1, 2.82, 0.16), Vector3(1.05, 0, 0), _mat(Color(0.26, 0.14, 0.075)), false)
	_box(leaf, Vector3(0.10, 0.10, 0.07), Vector3(1.70, 0, -0.12), _mat(Color(0.80, 0.62, 0.30)), false)
	var door_body := AnimatableBody3D.new()
	door_body.name = "DoorBody"
	var door_collision := CollisionShape3D.new()
	door_collision.name = "DoorCollision"
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(2.1, 2.82, 0.16)
	door_collision.shape = door_shape
	door_collision.position.x = 1.05
	door_body.add_child(door_collision)
	leaf.add_child(door_body)
	var plate := Label3D.new()
	plate.text = "%03d" % number
	plate.position = Vector3(1.05, 1.15, -0.10)
	plate.font_size = 60
	plate.modulate = Color(0.95, 0.83, 0.64)
	leaf.add_child(plate)
	door.set_meta("leaf", leaf)
	door_nodes.append(door)

func _update_door_prompt() -> void:
	if not is_instance_valid(player):
		return
	var closest: Node3D = null
	var best := 999.0
	for d in door_nodes:
		if is_instance_valid(d) and not d.get_meta("opened", false):
			var dist := player.global_position.distance_to(d.global_position)
			if dist < best:
				best = dist
				closest = d
	var closest_cabinet: Node3D = null
	var cabinet_distance := 999.0
	for cabinet in cabinet_nodes:
		if is_instance_valid(cabinet) and not cabinet.get_meta("searched", false):
			var dist := player.global_position.distance_to(cabinet.global_position)
			if dist < cabinet_distance:
				cabinet_distance = dist
				closest_cabinet = cabinet
	var shop_distance := player.global_position.distance_to(shop_node.global_position) if is_instance_valid(shop_node) else 999.0
	var closest_machine: Node3D = null
	var machine_distance := 999.0
	for machine in scream_machines:
		if is_instance_valid(machine) and not bool(machine.get_meta("activated", false)):
			var dist := player.global_position.distance_to(machine.global_position)
			if dist < machine_distance:
				machine_distance = dist
				closest_machine = machine
	var machine_in_range := is_instance_valid(closest_machine) and machine_distance < 3.5 and machine_distance < best and machine_distance < cabinet_distance and machine_distance < shop_distance
	var shop_in_range := is_instance_valid(shop_node) and shop_distance < 3.5 and shop_distance < best and shop_distance < cabinet_distance and not machine_in_range
	var cabinet_in_range := is_instance_valid(closest_cabinet) and cabinet_distance < 3.5 and cabinet_distance < best and cabinet_distance < shop_distance and not machine_in_range
	if machine_in_range:
		hint_text.text = _tr("E  |  IN DIE MASCHINE SCHREIEN", "E  |  SCREAM INTO THE MACHINE") if not mobile_controls else _tr("SCHREIEN", "SCREAM")
	elif shop_in_range:
		hint_text.text = _tr("E  |  SHOP ÖFFNEN", "E  |  OPEN SHOP") if not mobile_controls else _tr("ÖFFNEN: SHOP", "TAP OPEN: SHOP")
	elif cabinet_in_range:
		hint_text.text = _tr("E  |  SCHRANK DURCHSUCHEN", "E  |  SEARCH CABINET") if not mobile_controls else _tr("ÖFFNEN-TASTE: SCHRANK", "TAP OPEN: CABINET")
	elif closest and best < 3.5:
		hint_text.text = _tr("E  |  TÜR ÖFFNEN", "E  |  OPEN DOOR") if not mobile_controls else _tr("ÖFFNEN-TASTE: TÜR", "TAP OPEN: DOOR")
	else:
		hint_text.text = _tr("PFEILE: BEWEGEN   RUN: RENNEN   FEUER: Waffe   WISCHEN: KAMERA", "ARROWS: MOVE   RUN: SPRINT   FIRE: weapon   SWIPE: CAMERA") if mobile_controls else _tr("WASD BEWEGEN   MAUS KAMERA   SHIFT RENNEN   F WAFFE   ESC PAUSE", "WASD MOVE   MOUSE LOOK   SHIFT SPRINT   F WEAPON   ESC PAUSE")
	if Input.is_action_just_pressed("interact"):
		if machine_in_range:
			_use_scream_machine(closest_machine)
		elif shop_in_range:
			_open_shop_menu()
		elif cabinet_in_range:
			_search_cabinet(closest_cabinet)
		elif closest and best < 3.5:
			_open_door(closest)

func _search_cabinet(cabinet: Node3D) -> void:
	var room_id := int(cabinet.get_meta("room_id"))
	if cabinet.get_meta("searched", false):
		return
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_search_cabinet", room_id)
		return
	var roll := loot_rng.randf()
	var reward := 1 if roll < 0.25 else (2 if roll < 0.5 else 0)
	_apply_cabinet_search(room_id, reward)
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_cabinet_search", room_id, reward)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_search_cabinet(room_id: int) -> void:
	if not multiplayer.is_server() or searched_cabinets.has(room_id) or room_id > room_index:
		return
	var cabinet: Node3D = null
	for candidate in cabinet_nodes:
		if is_instance_valid(candidate) and int(candidate.get_meta("room_id", -1)) == room_id:
			cabinet = candidate
			break
	if not is_instance_valid(cabinet):
		return
	# Use one roll so money, bandages, and empty cabinets have fixed 25/25/50 odds.
	var roll := loot_rng.randf()
	var reward := 1 if roll < 0.25 else (2 if roll < 0.5 else 0)
	_apply_cabinet_search(room_id, reward)
	rpc("_rpc_apply_cabinet_search", room_id, reward)

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_cabinet_search(room_id: int, reward: int) -> void:
	_apply_cabinet_search(room_id, reward)

func _apply_cabinet_search(room_id: int, reward: int) -> void:
	searched_cabinets[room_id] = reward
	for cabinet in cabinet_nodes:
		if is_instance_valid(cabinet) and int(cabinet.get_meta("room_id")) == room_id:
			cabinet.set_meta("searched", true)
	if reward == 1:
		money += 10
		alert_text.text = _tr("Im Schrank: 10 $ gefunden!", "Found $10 in the cabinet!")
	elif reward == 2:
		bandages += 1
		alert_text.text = _tr("Im Schrank: Verband gefunden!", "Found a bandage in the cabinet!")
	else:
		alert_text.text = _tr("Der Schrank ist leer.", "The cabinet is empty.")
	alert_text.visible = true
	_refresh_inventory()
	get_tree().create_timer(2.5).timeout.connect(func(): if is_instance_valid(alert_text): alert_text.visible = false)

func _refresh_inventory() -> void:
	if is_instance_valid(inventory_text):
		inventory_text.text = _tr("Geld: $%d   Verbände: %d   Waffe: %d" % [money, bandages, weapon_ammo], "Money: $%d   Bandages: %d   Weapon: %d" % [money, bandages, weapon_ammo])

func _use_bandage() -> void:
	if bandages <= 0 or health >= 100:
		return
	bandages -= 1
	health = mini(100, health + 40)
	hud_health.value = health
	health_text.text = "%d / 100" % health
	alert_text.text = _tr("Verband benutzt (+40 Leben).", "Bandage used (+40 health).")
	alert_text.visible = true
	_refresh_inventory()

func _buy_shop_bandage() -> void:
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_shop_purchase")
		return
	if money < 5:
		_show_shop_purchase(false)
		return
	money -= 5
	bandages += 1
	_show_shop_purchase(true)
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_shop_purchase", true)

func _claim_room34_bonus() -> void:
	if room34_bonus_awarded or room_index != 34:
		return
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_room34_bonus")
		return
	_apply_room34_bonus()
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_room34_bonus")

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_room34_bonus() -> void:
	if not multiplayer.is_server() or room_index != 34 or room34_bonus_awarded:
		return
	_apply_room34_bonus()
	rpc("_rpc_apply_room34_bonus")

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_room34_bonus() -> void:
	_apply_room34_bonus()

func _apply_room34_bonus() -> void:
	if room34_bonus_awarded or room_index != 34:
		return
	room34_bonus_awarded = true
	money += 20
	alert_text.text = _tr("Shop-Bonus: 20 $ erhalten!", "Shop bonus: received $20!")
	alert_text.visible = true
	_refresh_inventory()

func _use_scream_machine(machine: Node3D) -> void:
	if not is_instance_valid(machine) or bool(machine.get_meta("activated", false)) or boss_defeated:
		return
	var number := int(machine.get_meta("machine_number", 0))
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_scream_machine", number)
		return
	_apply_scream_machine(number)
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_scream_machine", number, boss_health, boss_hits_taken)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_scream_machine(number: int) -> void:
	if not multiplayer.is_server() or room_index != 35 or boss_defeated:
		return
	_apply_scream_machine(number)
	rpc("_rpc_apply_scream_machine", number, boss_health, boss_hits_taken)

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_scream_machine(number: int, new_health: int, hits_taken: int) -> void:
	_apply_scream_machine(number, new_health, hits_taken)

func _apply_scream_machine(number: int, synced_health: int = -1, synced_hits: int = -1) -> void:
	var found_machine: Node3D = null
	for machine in scream_machines:
		if is_instance_valid(machine) and int(machine.get_meta("machine_number", -1)) == number:
			found_machine = machine
			break
	if not is_instance_valid(found_machine) or bool(found_machine.get_meta("activated", false)):
		return
	found_machine.set_meta("activated", true)
	for child in found_machine.get_children():
		if child is MeshInstance3D and child.mesh is BoxMesh:
			var material := _mat(Color(0.08, 0.58, 0.18))
			(child as MeshInstance3D).material_override = material
	if synced_health >= 0:
		boss_health = synced_health
		boss_hits_taken = synced_hits
	else:
		boss_hits_taken = mini(5, boss_hits_taken + 1)
		boss_health = maxi(0, boss_health - 50)
	if boss_health <= 0:
		boss_defeated = true
		_remove_monsters_of_kind("Boss1")
		alert_text.text = _tr("Boss besiegt! Öffne die Ausgangstür.", "Boss defeated! Open the exit door.")
	else:
		alert_text.text = _tr("Maschine %d/5 aktiviert! Bossleben: %d/250" % [boss_hits_taken, boss_health], "Machine %d/5 activated! Boss health: %d/250" % [boss_hits_taken, boss_health])
	alert_text.visible = true
	_refresh_hud_language()

func _open_shop_menu() -> void:
	if is_instance_valid(shop_dialog):
		return
	if room_index == 34:
		_claim_room34_bonus()
	shop_dialog = AcceptDialog.new()
	shop_dialog.title = _tr("Shop – Raum %d" % room_index, "Shop – Room %d" % room_index)
	shop_dialog.dialog_text = _tr("Raum 34: Du erhältst einmalig 20 $. Wähle einen Gegenstand.", "Room 34: You receive a one-time $20 bonus. Choose an item.") if room_index == 34 else _tr("Wähle einen Gegenstand. Die Waffe hat einen Schuss und besiegt Backterius 2.0.", "Choose an item. The weapon has one shot and defeats Backterius 2.0.")
	var options := VBoxContainer.new()
	options.add_theme_constant_override("separation", 10)
	var bandage_button := Button.new()
	bandage_button.text = _tr("Verband kaufen — 5 $", "Buy bandage — $5")
	bandage_button.custom_minimum_size = Vector2(460, 52)
	bandage_button.pressed.connect(_buy_bandage_from_shop)
	options.add_child(bandage_button)
	var weapon_button := Button.new()
	weapon_button.text = _tr("Waffe kaufen — 10 $ (1 Schuss)", "Buy weapon — $10 (1 shot)") if weapon_ammo <= 0 else _tr("Waffe bereits gekauft", "Weapon already purchased")
	weapon_button.custom_minimum_size = Vector2(460, 52)
	weapon_button.disabled = weapon_ammo > 0
	weapon_button.pressed.connect(_buy_weapon_from_shop)
	options.add_child(weapon_button)
	shop_dialog.add_child(options)
	add_child(shop_dialog)
	shop_dialog.confirmed.connect(_close_shop_dialog)
	shop_dialog.canceled.connect(_close_shop_dialog)
	shop_dialog.popup_centered(Vector2i(560, 340))

func _buy_bandage_from_shop() -> void:
	_buy_shop_bandage()
	_close_shop_dialog()

func _buy_weapon_from_shop() -> void:
	_buy_shop_weapon()
	_close_shop_dialog()

func _close_shop_dialog() -> void:
	if is_instance_valid(shop_dialog):
		shop_dialog.queue_free()
	shop_dialog = null

func _buy_shop_weapon() -> void:
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_shop_weapon_purchase")
		return
	if weapon_ammo > 0:
		_show_shop_weapon_purchase(false, true)
		return
	if money < 10:
		_show_shop_weapon_purchase(false)
		return
	money -= 10
	weapon_ammo = 1
	_show_shop_weapon_purchase(true)
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_shop_weapon_purchase", true)

func _show_shop_weapon_purchase(success: bool, already_owned: bool = false) -> void:
	if success:
		alert_text.text = _tr("Waffe gekauft. Ein Schuss ist geladen.", "Weapon bought. One shot is loaded.")
	elif already_owned:
		alert_text.text = _tr("Du hast die Waffe bereits.", "You already have the weapon.")
	else:
		alert_text.text = _tr("Du brauchst 10 $ für die Waffe.", "You need $10 for the weapon.")
	alert_text.visible = true
	_refresh_inventory()

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_shop_weapon_purchase() -> void:
	if not multiplayer.is_server():
		return
	var success := weapon_ammo <= 0 and money >= 10
	if success:
		money -= 10
		weapon_ammo = 1
		_show_shop_weapon_purchase(true)
	else:
		_show_shop_weapon_purchase(false, weapon_ammo > 0)
	rpc("_rpc_apply_shop_weapon_purchase", success)

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_shop_weapon_purchase(success: bool) -> void:
	if success:
		money -= 10
		weapon_ammo = 1
	_show_shop_weapon_purchase(success)

func _show_shop_purchase(success: bool) -> void:
	if success:
		alert_text.text = _tr("Verband gekauft. (-5 $)", "Bandage bought. (-$5)")
	else:
		alert_text.text = _tr("Du brauchst 5 $ für einen Verband.", "You need $5 to buy a bandage.")
	alert_text.visible = true
	_refresh_inventory()

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_shop_purchase() -> void:
	if not multiplayer.is_server():
		return
	var success := money >= 5
	if success:
		money -= 5
		bandages += 1
		_show_shop_purchase(true)
	else:
		_show_shop_purchase(false)
	rpc("_rpc_apply_shop_purchase", success)

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_shop_purchase(success: bool) -> void:
	if success:
		money -= 5
		bandages += 1
	_show_shop_purchase(success)

func _fire_weapon() -> void:
	if game_state != "playing":
		return
	if weapon_ammo <= 0:
		alert_text.text = _tr("Keine Munition. Kaufe im Shop eine Waffe für 10 $.", "No ammo. Buy a weapon for $10 in the shop.")
		alert_text.visible = true
		return
	if not is_instance_valid(camera) or not is_instance_valid(player):
		return
	var origin := camera.global_position
	var target_point := origin - camera.global_transform.basis.z * 45.0
	var query := PhysicsRayQueryParameters3D.create(origin, target_point)
	query.exclude = [player.get_rid()]
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		alert_text.text = _tr("Kein Monster im Visier.", "No monster in sight.")
		alert_text.visible = true
		return
	var target_object: Object = hit.get("collider")
	if not (target_object is Node3D) or str(target_object.get_meta("monster_kind", "")) != "Backterius 2.0":
		alert_text.text = _tr("Diese Waffe wirkt nur gegen Backterius 2.0.", "This weapon only works against Backterius 2.0.")
		alert_text.visible = true
		return
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_weapon_shot")
		return
	_apply_weapon_hit()
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_weapon_hit")

func _has_alive_monster(kind: String) -> bool:
	for monster in monster_nodes:
		if is_instance_valid(monster) and str(monster.get_meta("monster_kind", "")) == kind:
			return true
	return false

func _apply_weapon_hit() -> void:
	if weapon_ammo <= 0 or not _has_alive_monster("Backterius 2.0"):
		return
	weapon_ammo = maxi(0, weapon_ammo - 1)
	_remove_monsters_of_kind("Backterius 2.0")
	alert_text.text = _tr("Backterius 2.0 besiegt!", "Backterius 2.0 defeated!")
	alert_text.visible = true
	_refresh_inventory()

func _remove_monsters_of_kind(kind: String) -> void:
	for i in range(monster_nodes.size() - 1, -1, -1):
		var monster := monster_nodes[i]
		if not is_instance_valid(monster):
			monster_nodes.remove_at(i)
		elif str(monster.get_meta("monster_kind", "")) == kind:
			monster.queue_free()
			monster_nodes.remove_at(i)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_weapon_shot() -> void:
	if not multiplayer.is_server() or weapon_ammo <= 0 or not _has_alive_monster("Backterius 2.0"):
		return
	_apply_weapon_hit()
	rpc("_rpc_apply_weapon_hit")

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_weapon_hit() -> void:
	_apply_weapon_hit()

func _open_door(door: Node3D) -> void:
	var number := int(door.get_meta("number"))
	if _is_network_active() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_open_door", number)
		return
	_apply_door_open(number)
	if _is_network_active() and multiplayer.is_server():
		rpc("_rpc_apply_door_open", number)

func _apply_door_open(number: int, animate: bool = true) -> void:
	var door: Node3D = null
	for candidate in door_nodes:
		if is_instance_valid(candidate) and int(candidate.get_meta("number", -1)) == number:
			door = candidate
			break
	if not is_instance_valid(door) or door.get_meta("opened", false):
		return
	if room_index == 35 and number == 35 and not boss_defeated:
		alert_text.text = _tr("Der Boss lebt noch. Finde alle fünf Maschinen und schreie hinein!", "The boss is still alive. Find all five machines and scream into them!")
		alert_text.visible = true
		return
	door.set_meta("opened", true)
	_remove_room_monsters(room_index)
	var door_collision := door.find_child("DoorCollision", true, false) as CollisionShape3D
	if is_instance_valid(door_collision):
		door_collision.set_deferred("disabled", true)
	door_number = number
	if door_number >= TOTAL_ROOMS:
		if animate:
			var final_leaf: Node3D = door.get_meta("leaf")
			var final_tween := create_tween()
			final_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
			final_tween.tween_property(final_leaf, "rotation:y", -PI * 0.5, 0.85)
			await final_tween.finished
		_refresh_hud_language()
		_game_won()
		return
	_build_room()
	if animate:
		var leaf: Node3D = door.get_meta("leaf")
		var tween := create_tween()
		tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
		tween.tween_property(leaf, "rotation:y", -PI * 0.5, 0.85)
		await tween.finished
	_refresh_hud_language()
	_spawn_room_encounter()

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_open_door(number: int) -> void:
	if multiplayer.is_server() and number == door_number + 1:
		var door: Node3D = null
		for candidate in door_nodes:
			if is_instance_valid(candidate) and int(candidate.get_meta("number", -1)) == number:
				door = candidate
				break
		if is_instance_valid(door):
			_open_door(door)

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_door_open(number: int) -> void:
	_apply_door_open(number)

func _spawn_monster(kind: String) -> void:
	var monster := CharacterBody3D.new()
	monster.set_script(MONSTER_SCRIPT)
	monster.process_mode = Node.PROCESS_MODE_PAUSABLE
	monster.kind = kind
	monster.target = player
	monster.main_game = self
	var room_start := end_z + current_room_length
	if kind == "Dlhite":
		if rng.randf() < 0.55:
			var side := -1.0 if rng.randf() < 0.5 else 1.0
			monster.position = Vector3(side * (current_room_width * 0.5 - 0.35), rng.randf_range(2.2, 3.0), rng.randf_range(end_z + 2.0, room_start - 2.0))
			monster.set_meta("mount_surface", "wall")
		else:
			monster.position = Vector3(rng.randf_range(-current_room_width * 0.5 + 1.0, current_room_width * 0.5 - 1.0), 3.0, rng.randf_range(end_z + 2.0, room_start - 2.0))
			monster.set_meta("mount_surface", "ceiling")
	elif kind == "Boss1":
		monster.position = _boss_cell_center(Vector2i(6, 6))
	else:
		var half_width := maxf(current_room_width * 0.5 - 1.0, 0.5)
		var furthest_distance := maxf(current_room_length - 3.0, 3.5)
		var spawn_distance := rng.randf_range(3.5, minf(furthest_distance, 8.0))
		monster.position = Vector3(rng.randf_range(-half_width, half_width), 0, room_start - spawn_distance)
	monster.set_meta("monster_kind", kind)
	monster.set_meta("room_id", room_index)
	add_child(monster)
	monster_nodes.append(monster)
	if kind == "Backterius 2.0" or kind == "Boss1":
		alert_text.visible = false
		_flicker_lights_for_boss()
	else:
		alert_text.text = _tr(kind.to_upper() + " IST IN DER NÄHE", kind.to_upper() + " IS NEARBY")
		alert_text.visible = true
		var timer := get_tree().create_timer(3.0)
		timer.timeout.connect(func(): if is_instance_valid(alert_text): alert_text.visible = false)

func _flicker_lights_for_boss() -> void:
	for light in light_nodes:
		if not is_instance_valid(light) or not light.visible:
			continue
		var normal_energy := float(light.get_meta("normal_energy", light.light_energy))
		var tween := create_tween()
		tween.tween_property(light, "light_energy", normal_energy * 0.18, 0.08)
		tween.tween_property(light, "light_energy", normal_energy * 0.72, 0.11)
		tween.tween_property(light, "light_energy", normal_energy * 0.12, 0.07)
		tween.tween_property(light, "light_energy", normal_energy, 0.28)

func _update_monster_visibility(delta: float) -> void:
	if not is_instance_valid(player) or not is_instance_valid(camera):
		watched_dlhite_id = 0
		dlhite_watch_time = 0.0
		return
	var viewed_dlhite: Node3D = null
	var camera_origin := camera.global_position
	var camera_forward := -camera.global_transform.basis.z
	for monster in monster_nodes:
		if not is_instance_valid(monster):
			continue
		var sprite := monster.get_node_or_null("MonsterSprite") as Sprite3D
		var sight_point := sprite.global_position if is_instance_valid(sprite) else monster.global_position + Vector3(0, 1.0, 0)
		var to_monster := sight_point - camera_origin
		var distance := to_monster.length()
		if distance > 28.0 or distance < 0.1 or camera_forward.dot(to_monster / distance) < 0.93:
			continue
		var query := PhysicsRayQueryParameters3D.create(camera_origin, sight_point)
		query.exclude = [player.get_rid()]
		var sight_hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
		if sight_hit.is_empty() or sight_hit.get("collider") != monster:
			continue
		var kind := str(monster.get_meta("monster_kind", ""))
		_mark_monster_seen(kind)
		if kind == "Dlhite":
			viewed_dlhite = monster
	if is_instance_valid(viewed_dlhite):
		var current_id := viewed_dlhite.get_instance_id()
		if watched_dlhite_id == current_id:
			dlhite_watch_time += delta
		else:
			watched_dlhite_id = current_id
			dlhite_watch_time = delta
		var remaining := maxf(0.0, 2.0 - dlhite_watch_time)
		hint_text.text = _tr("DLHITE – WEGSEHEN! %.1f s" % remaining, "DLHITE — LOOK AWAY! %.1f s" % remaining)
		if dlhite_watch_time >= 2.0:
			alert_text.text = _tr("DLHITE HAT DICH ERWISCHT!", "DLHITE CAUGHT YOU!")
			alert_text.visible = true
			damage_player(100, "Dlhite")
			_remove_monster_node(viewed_dlhite)
	else:
		watched_dlhite_id = 0
		dlhite_watch_time = 0.0

func _remove_monster_node(monster: Node3D) -> void:
	if not is_instance_valid(monster):
		return
	monster_nodes.erase(monster)
	monster.queue_free()

func _remove_room_monsters(room_id: int) -> void:
	for i in range(monster_nodes.size() - 1, -1, -1):
		var monster := monster_nodes[i]
		if not is_instance_valid(monster):
			monster_nodes.remove_at(i)
		elif int(monster.get_meta("room_id", -1)) == room_id:
			monster.queue_free()
			monster_nodes.remove_at(i)

func _spawn_room_encounter() -> void:
	if room_index == 14 or room_index == 34:
		return
	if room_index == 25:
		_spawn_monster("Backterius 2.0")
		return
	if room_index == 35:
		_spawn_monster("Boss1")
		return
	if rng.randf() >= 0.72:
		return
	var encounter_roll := rng.randf()
	if encounter_roll < 0.48:
		_spawn_monster("Flymouth")
	elif encounter_roll < 0.70:
		_start_blackout()
	elif encounter_roll < 0.96:
		_spawn_monster("Dlhite")
	else:
		_spawn_monster("Backterius 2.0")

func _start_blackout() -> void:
	for light in light_nodes:
		if is_instance_valid(light):
			light.light_energy = 0.65
	_spawn_monster("Helius")
	await get_tree().create_timer(7.0).timeout
	if game_state == "playing":
		for light in light_nodes:
			if is_instance_valid(light):
				light.light_energy = 3.0

func _game_won() -> void:
	game_state = "won"
	get_tree().paused = true
	pause_overlay.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var col := pause_overlay.get_child(0).get_child(0)
	for child in col.get_children():
		child.queue_free()
	var title := Label.new()
	title.text = _tr("GESCHAFFT!", "YOU MADE IT!")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 32)
	title.add_theme_color_override("font_color", Color(0.95, 0.82, 0.65))
	col.add_child(title)
	var detail := Label.new()
	detail.text = _tr("Du hast alle 35 Räume durchquert und den Boss besiegt.", "You made it through all 35 rooms and defeated the boss.")
	detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(detail)
	_menu_button(col, _tr("NOCHMAL SPIELEN", "PLAY AGAIN"), _restart_game)
	_menu_button(col, _tr("HAUPTMENÜ", "MAIN MENU"), _return_to_menu)

func damage_player(amount: int, monster_name: String) -> void:
	if game_state != "playing":
		return
	health = maxi(0, health - amount)
	hud_health.value = health
	health_text.text = "%d / 100 HP" % health
	alert_text.text = _tr("%s: -%d LEBEN" % [monster_name, amount], "%s: -%d HEALTH" % [monster_name, amount])
	alert_text.visible = true
	if health <= 0:
		_game_over(monster_name)

func _game_over(monster_name: String) -> void:
	game_state = "paused"
	get_tree().paused = true
	pause_overlay.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	# replace pause content with a game over message
	var panel := pause_overlay.get_child(0)
	var col := panel.get_child(0)
	for child in col.get_children():
		child.queue_free()
	var title := Label.new()
	title.text = _tr("DU BIST GESTORBEN", "YOU DIED")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", Color(0.9, 0.22, 0.18))
	col.add_child(title)
	var detail := Label.new()
	detail.text = _tr("Erwischt von ", "Killed by ") + monster_name
	detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(detail)
	_menu_button(col, _tr("ERNEUT VERSUCHEN", "TRY AGAIN"), _restart_game)
	_menu_button(col, _tr("HAUPTMENÜ", "MAIN MENU"), _return_to_menu)

func _pause_game() -> void:
	if game_state != "playing":
		return
	game_state = "paused"
	get_tree().paused = true
	pause_overlay.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _resume_game() -> void:
	if game_state != "paused":
		return
	get_tree().paused = false
	game_state = "playing"
	pause_overlay.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _open_settings_from_menu() -> void:
	game_state = "settings"
	settings_overlay.visible = true
	menu_root.visible = false
	_rebuild_settings()

func _open_settings_from_pause() -> void:
	game_state = "settings"
	settings_overlay.visible = true
	pause_overlay.visible = false
	get_tree().paused = true
	_rebuild_settings()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _close_settings() -> void:
	settings_overlay.visible = false
	waiting_for_key = ""
	if player and is_instance_valid(player) and menu_root.visible == false and pause_overlay.visible == false:
		# Settings opened from pause if a player exists.
		game_state = "paused"
		get_tree().paused = true
		pause_overlay.visible = true
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		game_state = "menu"
		menu_root.visible = true
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _open_appearance() -> void:
	if appearance_dialog and is_instance_valid(appearance_dialog):
		appearance_dialog.queue_free()
	appearance_dialog = AcceptDialog.new()
	appearance_dialog.title = _tr("Aussehen", "Appearance")
	appearance_dialog.dialog_text = _tr("Wähle eine Spielerfarbe. Deine Auswahl wird lokal gespeichert.", "Choose a player color. Your choice is saved locally.")
	var choices := HBoxContainer.new()
	for i in range(appearance_colors.size()):
		var b := Button.new()
		b.text = appearance_names[i]
		b.modulate = appearance_colors[i]
		b.pressed.connect(_select_appearance.bind(i))
		choices.add_child(b)
	appearance_dialog.add_child(choices)
	add_child(appearance_dialog)
	appearance_dialog.confirmed.connect(_save_appearance)
	appearance_dialog.popup_centered()

func _select_appearance(index: int) -> void:
	appearance_color = appearance_colors[index]
	if player_body_mesh and is_instance_valid(player_body_mesh):
		var material := StandardMaterial3D.new()
		material.albedo_color = appearance_color
		player_body_mesh.material_override = material
	_save_appearance()

func _save_appearance() -> void:
	var file := FileAccess.open("user://appearance.cfg", FileAccess.WRITE)
	if file:
		file.store_var([appearance_color.r, appearance_color.g, appearance_color.b])

func _load_appearance() -> void:
	if not FileAccess.file_exists("user://appearance.cfg"):
		return
	var file := FileAccess.open("user://appearance.cfg", FileAccess.READ)
	if file:
		var values = file.get_var()
		if values is Array and values.size() == 3:
			appearance_color = Color(float(values[0]), float(values[1]), float(values[2]))

func _load_or_create_player_uuid() -> void:
	var config := ConfigFile.new()
	if config.load("user://identity.cfg") == OK:
		player_uuid = _format_uuid(_uuid_compact(str(config.get_value("identity", "uuid", ""))))
	if not player_uuid.is_empty():
		return

	var uuid_bytes: PackedByteArray = Crypto.new().generate_random_bytes(16)
	uuid_bytes[6] = (int(uuid_bytes[6]) & 15) | 64
	uuid_bytes[8] = (int(uuid_bytes[8]) & 63) | 128
	player_uuid = _format_uuid(uuid_bytes.hex_encode())
	config.set_value("identity", "uuid", player_uuid)
	config.save("user://identity.cfg")

func _uuid_compact(value: String) -> String:
	var compact := value.strip_edges().to_lower().replace("-", "")
	if compact.length() != 32:
		return ""
	for character in compact:
		if not "0123456789abcdef".contains(character):
			return ""
	return compact

func _format_uuid(compact: String) -> String:
	if compact.length() != 32:
		return ""
	return "%s-%s-%s-%s-%s" % [compact.substr(0, 8), compact.substr(8, 4), compact.substr(12, 4), compact.substr(16, 4), compact.substr(20, 12)]

func _open_multiplayer() -> void:
	if multiplayer_dialog and is_instance_valid(multiplayer_dialog):
		multiplayer_dialog.queue_free()
	multiplayer_dialog = ConfirmationDialog.new()
	multiplayer_dialog.title = "HALLROOMS Multiplayer"
	multiplayer_dialog.ok_button_text = _tr("Mit UUID beitreten", "Join with UUID")
	multiplayer_dialog.dialog_text = _tr("Mit einer Lobby-UUID über das Internet verbinden. Die Spieler müssen nicht im selben WLAN sein.", "Join a lobby over the internet with its UUID. Players do not need to be on the same Wi-Fi.")
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	var own_uuid_label := Label.new()
	own_uuid_label.text = _tr("Deine feste Spieler-UUID:", "Your permanent player UUID:")
	content.add_child(own_uuid_label)
	player_uuid_display = LineEdit.new()
	player_uuid_display.text = player_uuid
	player_uuid_display.editable = false
	player_uuid_display.select_all_on_focus = true
	player_uuid_display.custom_minimum_size = Vector2(460, 56)
	player_uuid_display.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	player_uuid_display.add_theme_font_size_override("font_size", 19)
	content.add_child(player_uuid_display)
	var host_uuid_label := Label.new()
	host_uuid_label.text = _tr("UUID der Lobby:", "Lobby UUID:")
	content.add_child(host_uuid_label)
	multiplayer_uuid_input = LineEdit.new()
	multiplayer_uuid_input.placeholder_text = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
	multiplayer_uuid_input.custom_minimum_size = Vector2(460, 56)
	multiplayer_uuid_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	multiplayer_uuid_input.virtual_keyboard_enabled = true
	multiplayer_uuid_input.max_length = 36
	multiplayer_uuid_input.add_theme_font_size_override("font_size", 19)
	content.add_child(multiplayer_uuid_input)
	multiplayer_dialog.add_child(content)
	var host_button := Button.new()
	host_button.text = _tr("Spiel hosten", "Host game")
	host_button.pressed.connect(_host_game)
	multiplayer_dialog.add_child(host_button)
	multiplayer_dialog.confirmed.connect(_join_game)
	multiplayer_dialog.canceled.connect(_on_multiplayer_dialog_canceled)
	add_child(multiplayer_dialog)
	multiplayer_dialog.popup_centered(Vector2i(620, 500))
	multiplayer_uuid_input.call_deferred("grab_focus")

func _host_game() -> void:
	var err := online_lobby.start_host(player_uuid, player_uuid)
	if err != OK:
		_show_network_message(_tr("Online-Server nicht eingerichtet. Trage seine WebSocket-Adresse in OnlineLobbyClient.gd ein und starte den Server. Fehler: ", "Online server is not configured. Set its WebSocket address in OnlineLobbyClient.gd and start the server. Error: ") + str(err))
		return
	if is_instance_valid(multiplayer_dialog):
		multiplayer_dialog.hide()
	network_status = "Online-Lobby wird gestartet …"
	_show_uuid_search_dialog(_tr("Online-Lobby wird gestartet …", "Starting online lobby …"))

func _join_game() -> void:
	var target_uuid := _uuid_compact(multiplayer_uuid_input.text)
	if target_uuid.is_empty():
		_show_network_message(_tr("Bitte eine gültige UUID eingeben (Format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).", "Enter a valid UUID (format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)."))
		return
	var err := online_lobby.join_room(_format_uuid(target_uuid), player_uuid)
	if err != OK:
		_show_network_message(_tr("Online-Server nicht eingerichtet. Trage seine WebSocket-Adresse in OnlineLobbyClient.gd ein und starte den Server. Fehler: ", "Online server is not configured. Set its WebSocket address in OnlineLobbyClient.gd and start the server. Error: ") + str(err))
		return
	if is_instance_valid(multiplayer_dialog):
		multiplayer_dialog.hide()
	network_status = "Suche Online-Lobby: " + _format_uuid(target_uuid)
	_show_uuid_search_dialog(_tr("Suche Lobby über ihre UUID …", "Searching for lobby by UUID …"))

func _on_multiplayer_dialog_canceled() -> void:
	if online_lobby:
		online_lobby.close()

func _show_uuid_search_dialog(message: String) -> void:
	_close_uuid_search_dialog()
	uuid_search_dialog = AcceptDialog.new()
	uuid_search_dialog.title = _tr("Online-Lobby", "Online lobby")
	uuid_search_dialog.dialog_text = message
	add_child(uuid_search_dialog)
	uuid_search_dialog.confirmed.connect(_cancel_uuid_search)
	uuid_search_dialog.canceled.connect(_cancel_uuid_search)
	uuid_search_dialog.popup_centered()

func _cancel_uuid_search() -> void:
	if online_lobby:
		online_lobby.close()
	if network_peer:
		network_peer.close()
		network_peer = null
		multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	_close_uuid_search_dialog()

func _close_uuid_search_dialog() -> void:
	if is_instance_valid(uuid_search_dialog):
		uuid_search_dialog.queue_free()
	uuid_search_dialog = null

func _on_connection_failed() -> void:
	network_status = "Verbindung fehlgeschlagen"
	if online_lobby:
		online_lobby.close()
	_close_uuid_search_dialog()
	_show_network_message(_tr("Verbindung fehlgeschlagen. Prüfe die UUID und ob die Online-Lobby noch läuft.", "Connection failed. Check the UUID and make sure the online lobby is still running."))

func _on_online_lobby_ready(peer: MultiplayerPeer, is_host: bool) -> void:
	network_peer = peer
	multiplayer.multiplayer_peer = network_peer
	if is_host:
		network_status = "Online-Host / UUID " + player_uuid
		rng.seed = MULTIPLAYER_WORLD_SEED
		_start_singleplayer()
		_close_uuid_search_dialog()
		_show_host_uuid_message()
	else:
		network_status = "Verbinde per UUID " + _format_uuid(online_lobby.room_uuid)
		if is_instance_valid(uuid_search_dialog):
			uuid_search_dialog.dialog_text = _tr("Lobby gefunden. Baue WebRTC-Verbindung auf …", "Lobby found. Establishing WebRTC connection …")
		if not multiplayer.connected_to_server.is_connected(_on_connected_to_server):
			multiplayer.connected_to_server.connect(_on_connected_to_server, CONNECT_ONE_SHOT)
		if not multiplayer.connection_failed.is_connected(_on_connection_failed):
			multiplayer.connection_failed.connect(_on_connection_failed, CONNECT_ONE_SHOT)

func _on_online_lobby_status(message: String) -> void:
	network_status = message

func _on_online_lobby_failed(message: String) -> void:
	network_status = "Verbindung fehlgeschlagen"
	if online_lobby:
		online_lobby.close()
	_close_uuid_search_dialog()
	_show_network_message(message)

func _show_host_uuid_message() -> void:
	var dialog := AcceptDialog.new()
	dialog.title = _tr("Deine Lobby-UUID", "Your lobby UUID")
	dialog.dialog_text = _tr("Die Online-Lobby läuft. Teile diese UUID mit den Mitspielern. Sie können sich über das Internet verbinden.", "The online lobby is running. Share this UUID with your players. They can join over the internet.")
	var uuid_field := LineEdit.new()
	uuid_field.text = player_uuid
	uuid_field.editable = false
	uuid_field.select_all_on_focus = true
	uuid_field.custom_minimum_size = Vector2(460, 56)
	uuid_field.add_theme_font_size_override("font_size", 19)
	dialog.add_child(uuid_field)
	add_child(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.popup_centered(Vector2i(600, 250))

func _on_connected_to_server() -> void:
	rng.seed = MULTIPLAYER_WORLD_SEED
	if game_state == "menu":
		_start_singleplayer()
	rpc_id(1, "_rpc_request_state")
	_close_uuid_search_dialog()
	_show_network_message(_tr("Mit Host verbunden. Spieler und Türen werden synchronisiert.", "Connected to host. Players and doors are being synchronized."))

func _show_network_message(message: String) -> void:
	var dialog := AcceptDialog.new()
	dialog.dialog_text = message
	add_child(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.popup_centered()

func _return_to_menu() -> void:
	get_tree().paused = false
	_disconnect_multiplayer()
	_clear_game_world()
	door_nodes.clear()
	light_nodes.clear()
	pause_overlay.visible = false
	settings_overlay.visible = false
	menu_root.visible = true
	game_state = "menu"
	_show_main_menu()

func _disconnect_multiplayer() -> void:
	if online_lobby:
		online_lobby.close()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	remote_players.clear()
	network_status = "Nicht verbunden"

func _restart_game() -> void:
	get_tree().paused = false
	pause_overlay.visible = false
	_start_singleplayer()

func _quit_game() -> void:
	get_tree().quit()

func _refresh_hud_language() -> void:
	if not door_text:
		return
	_refresh_inventory()
	door_text.text = _tr("HALLROOMS  /  RAUM %02d / %d" % [mini(room_index, TOTAL_ROOMS), TOTAL_ROOMS], "HALLROOMS  /  ROOM %02d / %d" % [mini(room_index, TOTAL_ROOMS), TOTAL_ROOMS])
	objective_text.text = _current_objective()
	health_text.text = ("%d / 100 LEBEN" % health) if current_language == "de" else ("%d / 100 HEALTH" % health)
	hint_text.text = (_tr("PFEILE BEWEGEN   RUN RENNEN   FEUER WAFFE   WISCHEN KAMERA", "ARROWS MOVE   RUN SPRINT   FIRE WEAPON   SWIPE CAMERA") if mobile_controls else _tr("WASD BEWEGEN   MAUS KAMERA   SHIFT RENNEN   F WAFFE   ESC PAUSE", "WASD MOVE   MOUSE LOOK   SHIFT SPRINT   F WEAPON   ESC PAUSE"))

func _current_objective() -> String:
	if room_index < 14:
		return _tr("ZIEL: Überlebe bis Raum 35. Shops sind in Raum 14 und 34.", "GOAL: Survive to Room 35. Shops are in Rooms 14 and 34.")
	if room_index == 14:
		return _tr("SHOP: Waffe 10 $ (ein Schuss) · Verband 5 $.", "SHOP: Weapon $10 (one shot) · Bandage $5.")
	if room_index == 34:
		return _tr("SHOP: Einmaliger Bonus 20 $ · Verband 5 $ · Boss kommt in Raum 35.", "SHOP: One-time $20 bonus · Bandage $5 · Boss is in Room 35.")
	if room_index == 35:
		if boss_defeated:
			return _tr("BOSS BESIEGT: Öffne die Ausgangstür.", "BOSS DEFEATED: Open the exit door.")
		return _tr("BOSS: Maschinen %d/5 · Leben %d/250 · Finde die roten Anzeigen." % [boss_hits_taken, boss_health], "BOSS: Machines %d/5 · Health %d/250 · Find the red displays." % [boss_hits_taken, boss_health])
	if room_index < TOTAL_ROOMS:
		return _tr("ZIEL: Erreiche Raum 35. Spare deine Ausrüstung für den Boss.", "GOAL: Reach Room 35. Save your supplies for the boss.")
	return _tr("ZIEL: Besiege den Boss und erreiche den Ausgang.", "GOAL: Defeat the boss and reach the exit.")
